<template>
	<view class="login">
		<view class="h1">您好！</view>
		<view class="h5">欢迎使用卡服邦门店管理系统</view>
		<view class="ipt num">
			<view class="text">账号</view>
			<input type="text" value="" placeholder="请输入账号" />
		</view>
		<view class="ipt psw">
			<view class="text">密码</view>
			<input :type="pswshow == false ? 'password' : ''" value="" placeholder="请输入密码" />
			<view class="icons" @click="pswshow = !pswshow">
				<image v-if="pswshow" src="../../static/images/eys_xiansi@2x.png" mode=""></image>
				<image v-if="!pswshow" src="../../static/images/eye@2x.png" mode=""></image>
			</view>
		</view>
		<view class="tologin" @click="tologin">登录</view>
	</view>
</template>

<script>
export default {
	data() {
		return {	pswshow:false,};
	},
	methods:{
		tologin(){
			uni.navigateTo({
				url:'../stores/Shome/Shome'
			})
		}
	}
};
</script>

<style lang="less" scoped>
.login {
	box-sizing: border-box;
	padding: 100rpx 30rpx;
	.h1 {
		font-size: 40rpx;
		color: #282828;
	}
	.h5 {
		font-size: 24rpx;
		color: #666666;
		box-sizing: border-box;
		padding: 30rpx 0;
	}
	.num {
		margin-top: 100rpx;
	}
	.ipt {
		box-sizing: border-box;
		padding: 30rpx 0;
		position: relative;
		.text {
			font-size: 32rpx;
			color: #333333;
		}
		input {
			width: 100%;
			background: #f7f7f7;
			height: 100rpx;
			border-radius: 5rpx;
			margin: 20rpx 0;
			font-size: 28rpx;
			color: #999999;
			box-sizing: border-box;
			padding: 0 10rpx;
		}
		.icons{
			position: absolute;
			top: 50%;
			right: 30rpx;
		}
		image {
			width: 40rpx;
			height: 40rpx;
			
		}
	}
	.tologin {
		width: 100%;
		height: 100rpx;
		line-height: 100rpx;
		color: #ffffff;
		text-align: center;
		font-size: 30rpx;
		background: #2d8cf0;
		border-radius: 10rpx;
		margin-top: 100rpx;
	}
}
</style>
