<template>
	<view class="addgoods">
		<view class="headertop">
			<topback :topback="'库存'" :type="'one'" :isleft="true" :isbule="false" :isaddpic="false" @change="topchange"></topback>
			<view class="selectbox">
				<Select @selected="getSelect" :options="options" :type="'server'"></Select>
				<Select @selected="getSelect" :options="options" :type="'server'"></Select>
			</view>
		</view>
		<view class="content">
			<view class="salelist">
				<view class="saleli" v-for="(item, index) in saleli" :key="index">
					<view class="mains">
						<view class="m-left" @click="tomain(item, index)">
							<image :src="item.img" mode=""></image>
							<image class="bq" v-if="item.ispt" src="../../../static/images/title_biaoqian@2x.png" mode=""></image>
						</view>
						<view class="m-right">
							<view class="goodsname">{{ item.goodsname }}</view>
							<view class="type-sale">
								<text class="type">{{ item.goodstype }}</text>
								<text class="sale">月售：{{ item.sale }}</text>
							</view>
							<view class="num-stock">
								<text class="num">{{ item.goodsnum }}</text>
								<text class="stock">库存：{{ item.stock }}</text>
							</view>
							<view class="price-account">
								<text class="price">￥{{ item.price }}</text>
								<view class="accout">
									<view class="replenishment item" v-if="item.replenishment">补货</view>
									<view class="inventory item" @click="toinventory">盘点</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';
import goodsitem from '../../../components/goodsitem/goodsitem';
import Select from '../../../components/Select/Select.vue';
export default {
	data() {
		return {
			ispop: false,
			issel: true,
			showindex: 0,
			tabbarlist: ['全部', '未结清', '已结清'],
			inputVal: '',
			isShow: false,
			options: [
				{
					name: '全部分组',
					code: '0'
				},
				{
					name: '零件',
					code: '1'
				},
				{
					name: '配件',
					code: '2'
				}
			],
			goodsinfo: [],
			supli: [{ name: '供应商1' }, { name: '供应商1' }, { name: '供应商1' }, { name: '供应商1' }, { name: '供应商1' }],
			saleli: [
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15555',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1,
					replenishment: true,
					ispt: true
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				}
			]
		};
	},

	methods: {
		getSelect(val) {
			console.log(val);
		},
		addnew() {
			this.issel = true;
			uni.navigateTo({
				url: '../addgoods/addgoods'
			});
		},
		toinventory() {
			uni.navigateTo({
				url: '../inventory/inventory'
			});
		},
		tozfgl() {
			this.issel = false;
			uni.navigateTo({
				url: '../goodsgroup/goodsgroup'
			});
		},
		tomain(item, index) {
			uni.navigateTo({
				url: '../goodsmain/goodsmain'
			});
		}
	},

	components: { topback, tabbar, goodsitem, Select }
};
</script>

<style lang="less" scoped>
.addgoods {
	width: 100%;
	background: #fafafa;
	position: relative;
}
.headertop {
	background: #ffffff;
	position: fixed;
	width: 100%;
	z-index: 111;
	top: 0;
	left: 0;
	.bg {
		position: absolute;
		top: 0;
		z-index: 111;
		width: 100%;
		height: 200rpx;
	}
	.selectbox {
		margin-top: 100rpx;
		background: #ffffff;
		width: 100%;
		height: 100rpx;
		display: flex;
		justify-content: space-around;
		position: relative;
		.pop {
			width: 30%;
			background: #ffffff;
			position: absolute;
			top: -10rpx;
			right: 40rpx;
			z-index: 11111111111111111;
			font-size: 28rpx;

			view {
				text-align: center;
				line-height: 60rpx;
			}
			.sel {
				color: #2d8cf0;
			}
		}
	}
	.tabs {
		width: 100%;
		box-sizing: border-box;
		padding: 0 15rpx;
		// height: 100rpx;
		background: #ffffff;
	}
}
.content {
	box-sizing: border-box;
	padding: 200rpx 30rpx 30rpx 30rpx;
	.salelist {
		width: 100%;
	}
}
.isbgs {
	background: rgba(0, 0, 0, 0.5);
}

.saleli {
	box-sizing: border-box;
	padding: 25rpx 15rpx;
	background: #ffffff;
	margin: 25rpx 0;
	.mains {
		width: 100%;
		display: flex;
		justify-content: space-between;
		.m-left {
			width: 30%;
			height: 150rpx;
			position: relative;
			image {
				width: 150rpx;
				height: 150rpx;
			}
			.bq {
				width: 150rpx;
				height: 34rpx;
				position: absolute;
				bottom: 0;
				left: 0;
			}
		}
		.m-right {
			width: 69%;
			.goodsname {
				font-size: 32rpx;
				font-weight: 500;
				color: #333333;
			}
			.type-sale {
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #666666;
				box-sizing: border-box;
				padding: 10rpx 0 15rpx 0;
				.type {
					width: 60%;

					font-size: 26rpx;
					text-overflow: ellipsis;
					overflow: hidden;
					white-space: nowrap;
				}
				.sale {
					font-size: 24rpx;
				}
			}
			.num-stock {
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #666666;
				font-size: 24rpx;
			}
			.price-account {
				box-sizing: border-box;
				padding-top: 20rpx;
				font-size: 32rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				.price {
					color: #e23a3a;
					font-weight: 500;
				}
				.accout {
					width: 60%;
					display: flex;
					justify-content: flex-end;
					align-items: center;
					.item {
						margin-right: 10rpx;
						width: 46%;
						height: 50rpx;
						background: #007aff;
						font-size: 30rpx;
						color: #ffffff;
						text-align: center;
						line-height: 50rpx;
						border-radius: 5rpx;
					}
				}
			}
		}
	}
}
</style>
