<template>
	<view class="editinfo">
		<view class="top"><topback :topback="'商品分组'" :iscenter="true" :isbg="true"></topback></view>
		<view class="content">
			<view class="box">
				<view class="groupli" v-for="(item, index) in list" :key="index">
					<input
						type="text"
						value=""
						:placeholder="item.name"
						placeholder-style="font-size: 28rpx;
					color: #333333;"
					/>
					<view class="setting">
						<image src="../../../static/images/icon_delete@2x.png" mode=""></image>
						<image src="../../../static/images/icon_bianji@2x.png" mode=""></image>
					</view>
				</view>
			</view>
			<view class="save">新增分组</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';

export default {
	data() {
		return {
			list: [{ name: '内饰清洁' }, { name: '内饰清洁' }, { name: '内饰清洁' }, { name: '内饰清洁' }]
		};
	},
	components: { topback }
};
</script>

<style lang="less" scoped>
.editinfo {
	width: 100%;
	background: #fafafa;
	position: relative;
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		// position: fixed;
		// top: 0;
		// left: 0;
		// z-index: 1111111;
	}
	.content {
		width: 100%;
		box-sizing: border-box;
		padding: 36rpx 30rpx;
		.box {
			width: 100%;
			.groupli {
				display: flex;
				justify-content: space-between;
				align-items: center;
				width: 100%;
				border-bottom: 1rpx solid #e5e5e5;
				box-sizing: border-box;
				padding: 20rpx 0;
				input {
					font-size: 28rpx;
					color: #333333;
				}
				.setting {
					width: 20%;
					display: flex;
					justify-content: space-around;
					image {
						width: 38rpx;
						height: 38rpx;
					}
				}
			}
		}
		.save {
			margin-top: 80rpx;
			width: 100%;
			height: 80rpx;
			background: #2d8cf0;
			text-align: center;
			line-height: 80rpx;
			color: #ffffff;
		}
	}
}
</style>
