<template>
	<view class="cusmain">
		<view class="top"><topback :topback="'库存变更记录'" :iscenter="true" :isbg="true"></topback></view>
		<tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar>

		<!-- 头部信息 -->

		<view class="cuslist">
			<view class="cusli" v-for="(item, index) in zdlist" :key="index" @click="tozdmain(item, index)">
				<image v-if="item.type == 0" src="../../../static/images/icon_chuku@2x.png" mode=""></image>
				<image v-if="item.type == 1" src="../../../static/images/icon_caigou@2x.png" mode=""></image>
				<view class="c-left">
					<view class="c-top flex">
						<text class="typename">{{ item.typename }}</text>
						<text class="num">{{ item.num }}</text>
					</view>
					<view class="c-center flex">
						<text class="name">{{ item.name }}</text>
						<text v-if="item.type == 0" class="green">- {{ item.price }}</text>
						<text v-if="item.type == 1" class="red">+ {{ item.price }}</text>
					</view>
					<view class="c-bot flex">
						<text class="note">备注：{{ item.note }}</text>
						<text class="time">{{ item.time }}</text>
					</view>
					<!-- <view class="name">
						<text>{{ item.name }}</text>
						<text v-if="item.type == 0" class="xz">- {{ item.price }}</text>
						<text v-if="item.type == 1" class="xs">+ {{ item.price }}</text>
					</view>
					<view class="time">{{ item.time }}</view> -->
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';

export default {
	data() {
		return {
			tabbarlist: ['全部', '出库', '入库'],
			showindex: 0,
			zdlist: [
				{
					typename: '线上采购待付',
					name: '张师傅',
					note: '采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库采购入库',
					price: '1',
					time: '2020-01-04 18:30',
					type: 0,
					num: '5649879879'
				},
				{
					typename: '线上采购待付',
					name: '张师傅',
					note: '采购入库',
					price: '1',
					time: '2020-01-04 18:30',
					type: 1,
					num: '5649879879'
				},
				{
					typename: '线上采购待付',
					name: '张师傅',
					note: '采购入库',
					price: '1',
					time: '2020-01-04 18:30',
					type: 1,
					num: '5649879879'
				}
			]
		};
	},
	components: { topback, tabbar },
	methods: {
		tozdmain(item, index) {},
		tonav(val) {
			this.showindex = val;
			console.log(this.showindex);
		}
	}
};
</script>

<style lang="less" scoped>
.cusmain {
	width: 100%;
	background: #fafafa;
	position: relative;
	box-sizing: border-box;
	padding-top: 120rpx;
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 1111111;
	}
}

.cuslist {
	width: 100%;
	box-sizing: border-box;
	padding: 30rpx 20rpx;
	.cusli {
		background: #ffffff;
		display: flex;
		justify-content: space-between;
		align-items: center;
		image {
			width: 105rpx;
			height: 100rpx;
		}
		.c-left {
			width: 83%;
			border-bottom: 1rpx solid #e5e5e5;
			box-sizing: border-box;
			padding: 30rpx 0;
			.flex {
				display: flex;
				justify-content: space-between;
				// align-items: center;
				color: #999999;
			}
			.c-top {
				justify-content: flex-start;

				.typename {
					font-size: 32rpx;
					color: #333333;
				}
				.num {
					font-size: 24rpx;
					color: #999999;
					box-sizing: border-box;
					padding-left: 30rpx;
				}
			}

			.c-center {
				box-sizing: border-box;
				padding: 10rpx 0;
				font-size: 28rpx;
				.name {
					font-size: 26rpx;
				}
				.green {
					color: #67c23a;
				}
				.red {
					color: #e23a3a;
				}
			}
			.c-bot {
				width: 100%;
				.note {
					width: 60%;
					// background: #4cd964;
					font-size: 20rpx;
					text-overflow: -o-ellipsis-lastline;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 3;
					line-clamp: 3;
					-webkit-box-orient: vertical;
				}
				.time {
					font-size: 24rpx;
				}
			}
			// .name {
			// 	font-size: 32rpx;
			// 	color: #333333;
			// 	display: flex;
			// 	line-height: 60rpx;
			// 	justify-content: space-between;
			// 	.gs {
			// 		color: #e23a3a;
			// 	}
			// 	.xs,
			// 	.xt {
			// 		color: #ffa928;
			// 	}

			// 	.xz {
			// 		color: #67c23a;
			// 	}
			// }
			// .time {
			// 	font-size: 24rpx;
			// 	color: #999999;
			// }
		}
		.c-right {
			width: 20%;
			font-size: 28rpx;
		}
	}
}
.headinfo {
	width: 100%;
	height: 400rpx;
	display: flex;
	justify-content: space-between;
	align-items: center;
	box-sizing: border-box;
	padding: 50rpx 30rpx;
	color: #ffffff;
	image {
		width: 140rpx;
		height: 140rpx;
		border-radius: 50%;
	}
	.notice {
		font-size: 20rpx;
		box-sizing: border-box;
		padding-top: 20rpx;
	}
	.infos {
		width: 75%;
		box-sizing: border-box;
		// padding-left: 20rpx;
		align-self: center;
		.title {
			font-size: 32rpx;
			box-sizing: border-box;
			padding-top: 80rpx;
		}
		.name-tle {
			box-sizing: border-box;
			padding-top: 20rpx;
			font-size: 28rpx;
		}

		.tel {
			font-size: 28rpx;
			box-sizing: border-box;
			padding-left: 20rpx;
		}
		.price {
			font-size: 30rpx;
			box-sizing: border-box;
			padding-top: 30rpx;
		}
	}
}
</style>
