<template>
	<view class="addgoods">
		<view class="top">
			<view class="bg isbgs" v-if="isShow == true || issupplier == true"></view>
			<topback :topback="'选择商品'" :iscenter="false" :isbg="true"></topback>
			<input type="text" value="" placeholder="搜索客户名称,联系人,手机号" />
			<view class="selectbox">
				<Select @selected="getSelect" :options="options"></Select>
				<Select @selected="getSelect" :options="options"></Select>
			</view>
		</view>

		<view class="content">
			<!-- tabbar -->
			<view class="salelist">
				<view class="saleli" v-for="(item, index) in saleli" :key="index">
					<view class="mains">
						<view class="m-left"><image :src="item.img" mode=""></image></view>
						<view class="m-right">
							<view class="goodsname">{{ item.goodsname }}</view>
							<view class="type-sale">
								<text class="type">{{ item.goodstype }}</text>
								<text class="sale">月售：{{ item.sale }}</text>
							</view>
							<view class="num-stock">
								<text class="num">{{ item.goodsnum }}</text>
								<text class="stock">库存：{{ item.stock }}</text>
							</view>
							<view class="price-account">
								<text class="price">￥{{ item.price }}</text>
								<view class="accout">
									<view @click="decrement(item, index)">-</view>
									{{ item.cart_num }}
									<view @click="increment(item, index)" :disabled="item.cart_num >= item.stock">+</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 购物单 -->
		<view class="accountlist" v-if="isShow">
			<view class="bg"></view>
			<view class="topinfo">
				<view class="allprice">
					<text class="ap">商品总价：{{ totalPrice | showPrice }}</text>
					<text class="toclean" @click="toclean">清空购物单</text>
				</view>
			</view>
			<view class="listbox">
				<view class="saleli" v-for="(item, index) in goodsinfo" :key="index">
					<view class="mains">
						<view class="m-left"><image :src="item.img" mode=""></image></view>
						<view class="m-right">
							<view class="goodsname">{{ item.goodsname }}</view>
							<view class="type-sale">
								<text class="type">{{ item.goodsnum }}</text>
							</view>
							<view class="price-account">
								<text class="price">￥{{ item.price }}</text>
								<view class="accout">
									<view @click="decrement(item, index)">-</view>
									{{ item.cart_num }}
									<view @click="increment(item, index)" :disabled="item.cart_num >= item.stock">+</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="botinfo"><view class="toaccount" @click="tosupplier">去结算</view></view>
		</view>
		<!-- 选择供应商 -->
		<view class="accountlist" v-if="issupplier">
			<view class="bg"></view>
			<view class="topinfo">
				<view class="allprice">
					<text class="toclean" @click="toclean">取消</text>
					<text class="ap">确定</text>
				</view>
			</view>
			<view class="listbox suplist">
				<view class=" supli" v-for="(item, index) in supli" :key="index" :class="supindex == index ? 'cursup' : ''" @click="changesup(index, item)">{{ item.name }}</view>
			</view>
			<view class="botinfo"><view class="toaccount" @click="toorder">去结算</view></view>
		</view>
		<view class="botinfo">
			<view class="icons"><image src="../../../static/logo.png" mode=""></image></view>
			<view class="allprice">商品总价：{{ totalPrice | showPrice }}</view>
			<view class="toaccount" @click="toaccount">去结算</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';
import goodsitem from '../../../components/goodsitem/goodsitem';
import Select from '../../../components/Select/Select.vue';
export default {
	data() {
		return {
			origin: '',
			showindex: 0,
			tabbarlist: ['全部', '未结清', '已结清'],
			inputVal: '',
			isShow: false,
			issupplier: false,
			supindex: 0,
			options: [
				{
					name: '全部分组',
					code: '0'
				},
				{
					name: '零件',
					code: '1'
				},
				{
					name: '配件',
					code: '2'
				}
			],
			goodsinfo: [],
			supli: [{ name: '供应商1' }, { name: '供应商1' }, { name: '供应商1' }, { name: '供应商1' }, { name: '供应商1' }],
			saleli: [
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				}
			]
		};
	},

	computed: {
		totalPrice() {
			return this.goodsinfo.reduce((previousValue, item) => previousValue + item.cart_num * item.price, 0);
		}
	},
	onLoad(options) {
		this.origin = options.from;
		console.log(this.origin);
	},
	methods: {
		decrement(item, index) {
			if (item.cart_num <= 1) {
				return;
			} else {
				item.cart_num--;
			}

			// this.goodsinfo[index].cart_num--;
			// let num = this.goodsinfo[index].cart_num;
			// console.log(num);
			// this.requstaddcar(item.user_id, item.goods_id, -1, item.format_ids);
		},
		// 数量+
		increment(item, index) {
			item.cart_num++;
			if (this.goodsinfo[index]) {
				this.goodsinfo[index] = item;
			} else {
				this.goodsinfo.push(item);
			}

			// this.goodsinfo[index].cart_num++;
			console.log(this.goodsinfo);
			// let num = this.goodsinfo[index].cart_num;
			// if (num >= item.goods_number) {
			// 	this.$message.error('库存不足！');
			// }
			// console.log(num);
			// this.requstaddcar(item.user_id, item.goods_id, 1, item.format_ids);
		},
		toaccount() {
			console.log(this.goodsinfo);
			if (this.goodsinfo.length == 0) {
				return;
			} else {
				this.isShow = true;
			}
		},
		// 选择供应商
		tosupplier() {
			this.isShow = false;
			this.issupplier = true;
		},
		changesup(index, item) {
			this.supindex = index;
		},
		toclean() {
			this.goodsinfo = [];
		},
		tonav(index) {
			this.showindex = index;
			console.log(index, 'index');
		},
		getSelect(val) {
			console.log(val);
		},
		toorder() {
			uni.navigateTo({
				url: '../order/order?from=' + this.origin
			});
		}
	},
	filters: {
		showPrice(price) {
			return '￥' + price.toFixed(2);
		}
	},
	components: { topback, tabbar, goodsitem, Select }
};
</script>

<style lang="less" scoped>

.addgoods {
	width: 100%;
	background: #fafafa;
	position: relative;
	.add {
		position: fixed;
		right: 20rpx;
		bottom: 20%;
		image {
			width: 138rpx;
			height: 138rpx;
		}
	}
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 1111111;
		display: flex;
		justify-content: space-around;
		align-items: center;
		.bg {
			position: absolute;
			top: 0;
			z-index: 111;
			width: 100%;
			height: 200rpx;
		}
		input {
			box-sizing: border-box;
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 20rpx;
			background: #ffffff;
			width: 60%;
			height: 55rpx;
			border-radius: 25rpx;
			padding: 0 25rpx;
			color: #b7b7b7;
			font-size: 24rpx;
		}
	}
}
.selectbox {
	background: #ffffff;
	position: fixed;
	top: 100rpx;
	left: 0;
	width: 100%;
	height: 100rpx;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	// view{
	// 	width: 80%;
	// 	box-sizing: border-box;
	// 	// margin-right: 10rpx;
	// }
}
.content {
	box-sizing: border-box;
	padding: 200rpx 30rpx 30rpx 30rpx;

	.salelist {
		width: 100%;
	}
}
.isbgs {
	background: rgba(0, 0, 0, 0.5);
}
.accountlist {
	position: fixed;
	z-index: 1111;
	bottom: 100rpx;
	left: 0;
	width: 100%;
	background: rgba(0, 0, 0, 0.5);
	.bg {
		width: 100%;
		height: 1500rpx;
	}
	.topinfo {
		background: #ffffff;
		border-radius: 16px 16px 0px 0px;
		width: 100%;
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		border-bottom: 1rpx solid #e5e5e5;
		.allprice {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 32rpx;
			color: #999999;
		}
		.ap {
			color: #2d8cf0;
			font-size: 32rpx;
		}
	}
	.listbox {
		background: #ffffff;
		box-sizing: border-box;
		padding: 30rpx 0;
		max-height: 400rpx;
		overflow-y: scroll;
	}
	.saleli {
		margin: 0 0;
		box-sizing: border-box;
		padding: 0rpx 30rpx;
	}
	.suplist {
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		background: #ffffff;
		width: 100%;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		.supli {
			width: 48%;
			background: #e5e5e5;
			height: 100rpx;
			margin-top: 30rpx;
			text-align: center;
			line-height: 100rpx;
			font-size: 32rpx;
			color: #333333;
		}
		.cursup {
			background: #2d8cf0;
			color: #ffffff;
		}
	}
	.botinfo {
		justify-content: flex-end;
	}
}
.saleli {
	box-sizing: border-box;
	padding: 25rpx 15rpx;
	background: #ffffff;
	margin: 25rpx 0;
	.mains {
		width: 100%;
		display: flex;
		justify-content: space-between;
		.m-left {
			width: 30%;

			image {
				width: 150rpx;
				height: 150rpx;
			}
		}
		.m-right {
			width: 69%;
			.goodsname {
				font-size: 32rpx;
				font-weight: 500;
				color: #333333;
			}
			.type-sale {
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #666666;
				box-sizing: border-box;
				padding: 10rpx 0 15rpx 0;
				.type {
					width: 60%;

					font-size: 26rpx;
					text-overflow: ellipsis;
					overflow: hidden;
					white-space: nowrap;
				}
				.sale {
					font-size: 24rpx;
				}
			}
			.num-stock {
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #666666;
				font-size: 24rpx;
			}
			.price-account {
				box-sizing: border-box;
				padding-top: 10rpx;
				font-size: 32rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				.price {
					color: #e23a3a;
					font-weight: 500;
				}
				.accout {
					// background: #007AFF;
					width: 40%;
					display: flex;
					justify-content: space-between;
					align-items: center;
				}
			}
		}
	}
}
.botinfo {
	position: fixed;
	bottom: 0;
	left: 0;
	width: 100%;
	height: 104rpx;
	background: #ffffff;
	box-shadow: 0px -2px 4px 0px #f7f7f7;
	display: flex;
	align-items: center;
	justify-content: space-between;
	box-sizing: border-box;
	padding: 0 30rpx;
	.icons {
		width: 40rpx;
		image {
			width: 40rpx;
			height: 40rpx;
		}
	}
	.allprice {
		font-size: 32rpx;
		color: #666666;
	}
	.toaccount {
		width: 200rpx;
		height: 60rpx;
		background: #2d8cf0;
		color: #ffffff;
		text-align: center;
		line-height: 60rpx;
		font-size: 32rpx;
	}
}
</style>
