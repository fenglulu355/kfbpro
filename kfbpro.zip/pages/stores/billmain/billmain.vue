<template>
	<view class="cusmain">
		<view class="top">
			<topback :type="'two'"
			 :topback="'账单详情'" 
			 :iscenter="true"
			 :iswhite='true'
			 ></topback></view>
		<!-- 头部信息 -->
		<view
			class="headinfo"
			style="background: url(../../../static/images/bg.png);
				background-position: center;
				background-size: cover;
				background-repeat: no-repeat;"
		>
			<image src="../../../static/logo.png" mode=""></image>
			<view class="infos">
				<view class="title">顺丰公司</view>
				<view class="name-tle">
					<text class="name">刘经理</text>
					<text class="tel">548948979</text>
				</view>
				<view class="price">
					余额：
					<text>-500.00</text>
				</view>
				<view class="notice">注意：更多账单信息请在pc端查看</view>
			</view>
		</view>

		<view class="cuslist">
			<view class="cusli" v-for="(item, index) in zdlist" :key="index" @click="tozdmain(item, index)">
				<image v-if="item.type == 0" src="../../../static/images/icon_daifu@2x.png" mode=""></image>
				<image v-if="item.type == 1" src="../../../static/images/icon_shouru.png" mode=""></image>
				<view class="c-left">
					<view class="name">
						<text>{{ item.name }}</text>
						<text v-if="item.type == 0" class="xz">- {{ item.price }}</text>
						<text v-if="item.type == 1" class="xs">+ {{ item.price }}</text>
					</view>
					<view class="time">{{ item.time }}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
export default {
	data() {
		return {
			zdlist: [
				{
					name: '线上采购待付',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '张三三',
					price: '1',
					time: '6468489',
					type: 1
				},{
					name: '线上采购待付',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '张三三',
					price: '1',
					time: '6468489',
					type: 1
				},{
					name: '线上采购待付',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '张三三',
					price: '1',
					time: '6468489',
					type: 1
				},{
					name: '线上采购待付',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '张三三',
					price: '1',
					time: '6468489',
					type: 1
				},{
					name: '线上采购待付',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '张三三',
					price: '1',
					time: '6468489',
					type: 1
				}
			]
		};
	},
	components: { topback },
	methods: {
		tozdmain(item, index) {}
	}
};
</script>

<style lang="less" scoped>
.cusmain {
	width: 100%;
	height: 100%;
	position: relative;
	.top {
		width: 100%;
		position: absolute;
		top: 0;
	}
}

.cuslist {
	width: 100%;
	box-sizing: border-box;
	padding: 30rpx 20rpx;
	.cusli {
		background: #ffffff;
		display: flex;
		justify-content: space-between;
		align-items: center;
		image {
			width: 105rpx;
			height: 100rpx;
		}
		.c-left {
			width: 83%;
			border-bottom: 1rpx solid #e5e5e5;
			box-sizing: border-box;
			padding: 30rpx 0;
			.name {
				font-size: 32rpx;
				color: #333333;
				display: flex;
				line-height: 60rpx;
				justify-content: space-between;
				.gs {
					color: #e23a3a;
				}
				.xs,
				.xt {
					color: #ffa928;
				}

				.xz {
					color: #67c23a;
				}
			}
			.time {
				font-size: 24rpx;
				color: #999999;
			}
		}
		.c-right {
			width: 20%;
			font-size: 28rpx;
		}
	}
}
.headinfo {
	width: 100%;
	height: 400rpx;
	display: flex;
	justify-content: space-between;
	align-items: center;
	box-sizing: border-box;
	padding: 50rpx 30rpx;
	color: #ffffff;
	image {
		width: 140rpx;
		height: 140rpx;
		border-radius: 50%;
	}
	.notice {
		font-size: 20rpx;
		box-sizing: border-box;
		padding-top: 20rpx;
	}
	.infos {
		width: 75%;
		box-sizing: border-box;
		// padding-left: 20rpx;
		align-self: center;
		.title {
			font-size: 32rpx;
			box-sizing: border-box;
			padding-top: 80rpx;
		}
		.name-tle {
			box-sizing: border-box;
			padding-top: 20rpx;
			font-size: 28rpx;
		}

		.tel {
			font-size: 28rpx;
			box-sizing: border-box;
			padding-left: 20rpx;
		}
		.price {
			font-size: 30rpx;
			box-sizing: border-box;
			padding-top: 30rpx;
		}
	}
}
</style>
