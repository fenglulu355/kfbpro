<template>
	<view class="cusmain">
		<view class="top"><topback :topback="'账单详情'" :iscenter="true"></topback></view>
		<view class="pcontent">
			<view class="price">金额</view>
			<view class="iptbox"><input type="text" value="" placeholder="￥6464" /></view>

			<view class="proname common">
				<text class="text">项目名称</text>
				<text class="main">车子维修保养</text>
			</view>
			<view class="times common">
				<text class="text">交易时间</text>
				<text class="main">
					2020-02-06 15：00
					<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
				</text>
			</view>
			<view class="note">
				备注
				<textarea value="" placeholder="点击填写" />
			</view>
			<view class="btn">确定</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
export default {
	data() {
		return {};
	},
	components: { topback },
	methods: {
		tozdmain(item, index) {}
	}
};
</script>

<style lang="less" scoped>
.cusmain {
	width: 100%;
	height: 100%;

	position: relative;
	box-sizing: border-box;
	padding: 120rpx 0rpx;
	.top {
		background: #2d8cf0;
		width: 100%;
		position: absolute;
		top: 0;
	}
}
.price {
	background: #ffffff;
	width: 100%;

	color: #282828;
	font-size: 28rpx;
}
.iptbox {
	background: #ffffff;
	width: 100%;
	border-bottom: 1rpx solid #e5e5e5;
	input {
		font-size: 60rpx;
		color: #282828;
	}
}

.common {
	background: #ffffff;
	display: flex;
	justify-content: space-between;
	align-items: center;
	color: #666666;
	border-bottom: 1rpx solid #e5e5e5;
	box-sizing: border-box;
	padding: 30rpx 0;
	.text {
		font-size: 28rpx;
	}
	.main {
		color: #282828;
		font-size: 26rpx;
	}
}
.proname {
	box-sizing: border-box;
	padding-top: 80rpx;
}
.times {
	.main {
		color: #666666;
		image {
			margin-left: 20rpx;
			width: 12rpx;
			height: 21rpx;
		}
	}
}
.note {
	background: #ffffff;
	font-size: 28rpx;
	color: #666666;
	box-sizing: border-box;
	padding: 40rpx 0;
	textarea {
		width: 100%;
		height: 150rpx;
		background: #fafafa;
		border-radius: 5px;
		font-size: 26rpx;
		color: #999999;
		box-sizing: border-box;
		padding: 20rpx 20rpx;
	}
}
.btn {
	margin-top: 200rpx;
	width: 100%;
	height: 100rpx;
	line-height: 100rpx;
	text-align: center;
	color: #ffffff;
	font-size: 30rpx;
	background: #2d8cf0;
}
</style>
