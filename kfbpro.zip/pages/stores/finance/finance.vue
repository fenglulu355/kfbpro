<template>
	<view class="service">
		<view class="ser-head">
			<view class="search">
				<topback :topback="'财务'" :iscenter="false"></topback>
				<input type="text" value="" placeholder="搜索服务名称" />
			</view>
			<tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar>
		</view>
		<view class="content" v-if="showindex == 0">
			<view class="selectbox" @click="ispop = true">
				全部交易类型
				<image src="../../../static/images/icon_xiala@2x.png" mode=""></image>
			</view>
			<view class="datas">
				<view class="time" @click="tochangedata">
					<text>2020年8月</text>
					<image src="../../../static/images/icon_xiala@2x.png" mode=""></image>
				</view>
				<view class="income">
					<text>收入￥546768</text>
					<text>支出￥546768</text>
				</view>
			</view>
			<view class="cuslist">
				<view class="cusli" v-for="(item, index) in cuslist" :key="index" @click="tomain(item, index)">
					<image v-if="item.type == 1" src="../../../static/images/icon_shouru.png" mode=""></image>
					<image v-if="item.type == 2" src="../../../static/images/icon_tuikuan.png" mode=""></image>
					<image v-if="item.type == 3" src="../../../static/images/icon_zhichu2.png" mode=""></image>
					<image v-if="item.type == 0" src="../../../static/images/icon_shouru2.png" mode=""></image>
					<view class="c-left">
						<view class="name">
							<text>{{ item.name }}</text>
							<text v-if="item.type == 0" class="gs">+{{ item.price }}</text>
							<text v-if="item.type == 1" class="xs">+{{ item.price }}</text>
							<text v-if="item.type == 2" class="xt">+{{ item.price }}</text>
							<text v-if="item.type == 3" class="xz">-{{ item.price }}</text>
						</view>
						<view class="time">{{ item.time }}</view>
					</view>
				</view>
			</view>
			<view class="pop" v-show="ispop">
				<view class="bg"></view>
				<view class="popbox">
					<view class="popli" v-for="(item, index) in select" :key="index" @click="changesel(index)" :class="selindex == index ? 'sel' : ''">{{ item }}</view>
				</view>
			</view>
		</view>
		<view class="content" v-if="showindex == 1">
			<view class="selectbox" @click="ispop = true">
				客户账单
				<image src="../../../static/images/icon_xiala@2x.png" mode=""></image>
			</view>
			<view class="datas">
				<view class="time" @click="tochangedata">
					<text>2020年8月</text>
					<image src="../../../static/images/icon_xiala@2x.png" mode=""></image>
				</view>
				<view class="income">
					<text>收入￥546768</text>
					<text>支出￥546768</text>
				</view>
			</view>
			<view class="cuslist">
				<view class="cusli" v-for="(item, index) in zdlist" :key="index" @click="tozdmain(item, index)">
					<image v-if="item.type == 0" src="../../../static/images/icon_daifu@2x.png" mode=""></image>
					<image v-if="item.type == 1" src="../../../static/images/icon_shouru.png" mode=""></image>
					<view class="c-left">
						<view class="name">
							<text>{{ item.name }}</text>
							<text v-if="item.type == 0" class="xs">欠款 {{ item.price }}</text>
							<text v-if="item.type == 1" class="xs">欠款 {{ item.price }}</text>
						</view>
						<view class="time">{{ item.time }}</view>
					</view>
				</view>
			</view>
			<view class="pop" v-show="ispop">
				<view class="bg"></view>
				<view class="popbox">
					<view class="popli" v-for="(item, index) in select" :key="index" @click="changesel(index)" :class="selindex == index ? 'sel' : ''">{{ item }}</view>
				</view>
			</view>
		</view>
		<minpopup size="height" :show="show1" @close="close"><minpicker :endTime="endTime" :startTime="startTimes" @cancel="cancel" @sure="sure"></minpicker></minpopup>
	</view>
</template>

<script>
import cusitem from '../../../components/listvertical/listvertical.vue';
import topback from '../../../components/topback/topback.vue';
import Select from '../../../components/Select/Select.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';
import minpicker from '../../../components/min-picker/min-picker.vue';
import minpopup from '../../../components/min-picker/min-popup.vue';
export default {
	data() {
		return {
			show1: false,
			ispop: false,
			tabbarlist: ['收入/支出', '账单'],
			showindex: 0,
			selindex: 0,
			startTimes: [2010, 6, 1],
			endTime: 2046,
			select: ['全部', '条件一', '条件一', '条件一', '条件一', '条件一', '条件一'],
			zdlist: [
				{
					name: '线上采购待付',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '张三三',
					price: '1',
					time: '6468489',
					type: 1
				}
			],
			cuslist: [
				{
					name: '工单收入',
					price: '1',
					time: '6468489',
					type: 0
				},
				{
					name: '销售收入',
					price: '153',
					time: '6468489',
					type: 1
				},
				{
					name: '线下采购退款',
					price: '1123',
					time: '6468489',
					type: 2
				},
				{
					name: '线上采购支出',
					price: '164',
					time: '6468489',
					type: 3
				}
			]
		};
	},

	methods: {
		tochangedata() {
			this.show1 = true;
		},
		// 取消事件
		cancel() {
			this.show1 = false;
		},
		// 确认事件
		sure(e) {
			console.log(e, 'a');
			setTimeout(function() {
				this.show1 = false;
			}, 500);
			// 输出 { year: 2020,month: 3,day: 23}
		},
		// picker显示
		showPop() {
			this.show = true;
		},
		// 关闭picker
		close() {
			this.show = false;
		},

		tomain(item, index) {
			uni.navigateTo({
				url: '../incmain/incmain'
			});
		},
		tozdmain(item, index) {
			uni.navigateTo({
				url: '../billmain/billmain'
			});
		},
		changesel(index) {
			this.selindex = index;
			// setTimeout(function() {
			// 	this.ispop = false;
			// 	console.log(this.ispop);
			// }, 500);
			this.ispop = false;
			this.$forceUpdate();
			console.log(this.ispop);
		},
		tocuritem(index, item) {
			console.log(index, item, 'e');
			uni.navigateTo({
				url: '../cusmain/cusmain'
			});
		},
		edit(val) {
			console.log(val, 'edit');
			uni.navigateTo({
				url: '../editserv/editserv'
			});
		},
		del(val) {
			console.log(val, 'del');
		},
		getSelect(val) {
			console.log(val);
		},
		togroup() {
			uni.navigateTo({
				url: '../editservgroup/editservgroup'
			});
		},
		tonav(val) {
			this.showindex = val;
			console.log(this.showindex);
		}
	},
	components: {
		cusitem,
		topback,
		Select,
		tabbar,
		minpopup,
		minpicker
	}
};
</script>

<style lang="less" scoped>
.service {
	width: 100%;
	box-sizing: border-box;
	padding-top: 300rpx;
	.ser-head {
		width: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 1111111;
		background: #ffffff;
	}
	.selectbox {
		width: 100%;
		height: 100rpx;
		background: #ffffff;
		line-height: 100rpx;
		position: fixed;
		top: 185rpx;
		left: 0;
		z-index: 1111111;
		font-size: 32rpx;
		color: #666666;
		text-align: center;
		image {
			width: 21rpx;
			height: 12rpx;
			padding-left: 20rpx;
		}
	}
	.search {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		display: flex;
		justify-content: space-around;
		align-items: center;
		color: white;
		position: relative;
		color: #ffffff;
		input {
			box-sizing: border-box;
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 20rpx;
			background: #ffffff;
			width: 70%;
			height: 55rpx;
			border-radius: 25rpx;
			padding: 0 25rpx;
			color: #b7b7b7;
			font-size: 24rpx;
		}
	}
	.content {
		// background: #007aff;
	}
	.datas {
		width: 100%;
		.time {
			font-size: 32rpx;
			color: #333333;
			image {
				padding-left: 20rpx;
				width: 21rpx;
				height: 12rpx;
			}
		}
		.income {
			color: #666666;
			font-size: 28rpx;
			line-height: 70rpx;
			text {
				margin-right: 40rpx;
			}
		}
	}
	.pop {
		background: rgba(0, 0, 0, 0.5);
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		z-index: 11111111111;
		height: 10000rpx;
		.popbox {
			position: absolute;
			bottom: 0;
			background: #ffffff;
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-wrap: wrap;
			box-sizing: border-box;
			padding: 30rpx 30rpx;
			border-radius: 16px 16px 0px 0px;
			max-height: 500rpx;
			overflow-y: scroll;
			.popli {
				width: 48%;
				height: 100rpx;
				background: #e5e5e5;
				border-radius: 5px;
				text-align: center;
				line-height: 100rpx;
				font-size: 32rpx;
				color: #333333;
				margin-bottom: 20rpx;
			}
			.sel {
				background: #2d8cf0;
				color: #ffffff;
			}
		}
	}
	.cuslist {
		width: 100%;
		box-sizing: border-box;
		padding: 30rpx 20rpx;
		.cusli {
			background: #ffffff;
			display: flex;
			justify-content: space-between;
			align-items: center;
			image {
				width: 105rpx;
				height: 100rpx;
			}
			.c-left {
				width: 83%;
				border-bottom: 1rpx solid #e5e5e5;
				box-sizing: border-box;
				padding: 30rpx 0;
				.name {
					font-size: 32rpx;
					color: #333333;
					display: flex;
					line-height: 60rpx;
					justify-content: space-between;
					.gs {
						color: #e23a3a;
					}
					.xs,
					.xt {
						color: #ffa928;
					}

					.xz {
						color: #67c23a;
					}
				}
				.time {
					font-size: 24rpx;
					color: #999999;
				}
			}
			.c-right {
				width: 20%;
				font-size: 28rpx;
			}
		}
	}
}
</style>
