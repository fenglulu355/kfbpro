<template>
	<view class="customer">
		<view class="search">
			<topback :topback="'客户'" :iscenter='false'></topback>
			<input type="text" value="" placeholder="搜索客户名称,联系人,手机号" />
		</view>

		<view class="cuslist">
			<view class="cusli" v-for="(item, index) 
			in cuslist" :key="index"
			 @click="tocuritem(index, item)">
			 <cusitem :curinfo="item"></cusitem></view>
		</view>
		<view class="addcus">新增客户</view>
	</view>
</template>

<script>
import cusitem from '../../../components/listvertical/listvertical.vue';
import topback from '../../../components/topback/topback.vue';

export default {
	data() {
		return {
			cuslist: [
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				}
			]
		};
	},
	methods: {
		tocuritem(index, item) {
			console.log(index, item, 'e');
			uni.navigateTo({
				url: '../cusmain/cusmain'
			});
		}
	},
	components: {
		cusitem,
		topback
	}
};
</script>

<style lang="less" scoped>
.customer {
	width: 100%;
	.search {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		display: flex;
		justify-content: space-around;
		align-items: center;
		color: white;
		position: relative;
		color: #FFFFFF;
		input {
			box-sizing: border-box;
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 20rpx;
			background: #ffffff;
			width: 70%;
			height: 55rpx;
			border-radius: 25rpx;
			padding: 0 25rpx;
			color: #b7b7b7;
			font-size: 24rpx;
		}
	}
	.cuslist {
		width: 100%;
		box-sizing: border-box;
		padding: 20rpx 20rpx;
		.cusli {
			box-sizing: border-box;
			padding: 15rpx 0rpx;
			background: #ffffff;
			border-bottom: 1rpx solid #e5e5e5;
		}
	}
	.addcus {
		width: 80%;
		height: 100rpx;
		background: #2D8CF0;
		text-align: center;
		line-height: 100rpx;
		color: #ffffff;
		position: fixed;
		bottom: 20rpx;
		left: 50%;
		transform: translateX(-50%);
		box-shadow: 0px 4px 6px 0px rgba(250, 250, 250, 0.6);
		
	}
}
</style>
