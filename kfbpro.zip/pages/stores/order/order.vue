<template>
	<view class="order">
		<view class="top" v-if="origin == 'sales'"><topback :topback="'确认销售单'" :iscenter="true"></topback></view>
		<view class="top" v-if="origin == 'purchase'"><topback :topback="'确认采购单'" :iscenter="true"></topback></view>
		<view class="addcus" v-if="origin == 'sales'">
			<image src="../../../static/images/add.png" mode=""></image>
			<view class="text">添加客户</view>
		</view>
		<view class="cusinfos" v-if="origin == 'sales'">
			<view class="cus"><listvertical :curinfo="curinfo"></listvertical></view>
		</view>
		<view class="cusinfos " v-if="origin == 'purchase'">
			<view class="ci-top">
				<text class="name">采购员李师傅</text>
				<text class="tel">64648678</text>
			</view>
			<view class="address">
				<text class="text">地址：</text>
				<text class="ads">哀诉好低啊u上帝阿斯顿阿士东哈怂电话奥斯丁和奥数啊</text>
			</view>
			<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
		</view>
		<view class="accountlist">
			<view class="topinfo">
				<view class="allprice">
					<text class="ap">商品总价：{{ totalPrice | showPrice }}</text>
					<text class="toclean" @click="toclean">清空购物单</text>
				</view>
			</view>
			<view class="listbox">
				<view class="saleli" v-for="(item, index) in saleli" :key="index">
					<view class="mains">
						<view class="m-left"><image :src="item.img" mode=""></image></view>
						<view class="m-right">
							<view class="goodsname">{{ item.goodsname }}</view>
							<view class="type-sale">
								<text class="type">{{ item.goodsnum }}</text>
							</view>
							<view class="price-account">
								<text class="price">￥{{ item.price }}</text>
								<view class="accout">
									<view @click="decrement(item, index)">-</view>
									{{ item.cart_num }}
									<view @click="increment(item, index)" :disabled="item.cart_num >= item.stock">+</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="iptmain" v-if="origin == 'sales'">
			<view class="iptbox">
				<view class="text">车辆识别代码</view>
				<input type="text" value="" placeholder="点击填写" />
			</view>
			<view class="iptbox">
				<view class="text">所有人</view>
				<input type="text" value="" placeholder="点击填写" />
			</view>
			<view class="iptbox last">
				<view class="text">住址</view>
				<input type="text" value="" placeholder="点击填写" />
			</view>
		</view>
		<view class="tobtn">
			<view class="btnitem">添加商品</view>
			<view class="btnitem" @click="tocurmain">去结算</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import listvertical from '../../../components/listvertical/listvertical.vue';
export default {
	data() {
		return {
			origin: '',
			curinfo: {
				icon: '../../../static/logo.png',
				title: '十点十分我问',
				name: '士大夫阿斯顿',
				tel: '3216548978'
			},
			saleli: [
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				}
			]
		};
	},
	computed: {
		totalPrice() {
			return this.saleli.reduce((previousValue, item) => previousValue + item.cart_num * item.price, 0);
		}
	},
	onLoad(options) {
		this.origin = options.from;
		console.log(this.origin);
	},
	methods: {
		decrement(item, index) {
			item.cart_num--;
		},
		// 数量+
		increment(item, index) {
			item.cart_num++;
			console.log(this.goodsinfo);
		},
		// 跳转至详情确认
		tocurmain(){
			uni.navigateTo({
				url:'../salesmain/salesmain?from='+this.origin 
			})
		}
	},
	filters: {
		showPrice(price) {
			return '￥' + price.toFixed(2);
		}
	},
	components: { topback, listvertical }
};
</script>

<style lang="less" scoped>
.order {
	width: 100%;
	background: #fafafa;
	position: relative;
	box-sizing: border-box;
	padding-top: 100rpx;
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 11;
	}
	.cusinfos {
		background: #ffffff;
		box-sizing: border-box;
		margin: 30rpx 0;
		padding: 30rpx 30rpx;
		position: relative;
		.cus {
			box-sizing: border-box;
			padding: 30rpx 15rpx;
		}
		.ci-top {
			.name {
				color: #282828;
				font-size: 32rpx;
			}
			.tel {
				font-size: 28rpx;
				color: #666666;
				padding-left: 30rpx;
			}
		}
		.address {
			box-sizing: border-box;
			padding: 20rpx 0;
			font-size: 26rpx;
			color: #999999;
			display: flex;
			justify-content: flex-start;
			.text {
				width: 13%;
			}
			.ads {
				width: 70%;
			}
		}
		image {
			position: absolute;
			right: 30rpx;
			top: 50%;
			transform: translateX(-50%);
			width: 12rpx;
			height: 21rpx;
		}
	}
	.addcus {
		background: #ffffff;
		box-sizing: border-box;
		margin: 30rpx 0;
		text-align: center;
		padding: 30rpx 0;

		image {
			width: 55rpx;
			height: 55rpx;
		}
		.text {
			color: #333333;
			font-size: 24rpx;
			box-sizing: border-box;
			padding-top: 20rpx;
		}
	}
	.accountlist {
		width: 100%;
		box-sizing: border-box;
		padding: 0 30rpx;
		.topinfo {
			background: #ffffff;
			width: 100%;
			box-sizing: border-box;
			padding: 30rpx 30rpx;
			border-bottom: 1rpx solid #e5e5e5;
			.allprice {
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: 32rpx;
				color: #999999;
			}
			.ap {
				color: #2d8cf0;
				font-size: 32rpx;
			}
		}
		.listbox {
			background: #ffffff;
			box-sizing: border-box;
			padding: 0rpx 15rpx;
		}
		.saleli {
			box-sizing: border-box;
			padding: 25rpx 15rpx;
			background: #ffffff;
			.mains {
				width: 100%;
				display: flex;
				justify-content: space-between;
				.m-left {
					width: 30%;
					image {
						width: 150rpx;
						height: 150rpx;
					}
				}
				.m-right {
					width: 69%;
					.goodsname {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
					}
					.type-sale {
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666666;
						box-sizing: border-box;
						padding: 10rpx 0 15rpx 0;
						.type {
							width: 60%;

							font-size: 26rpx;
							text-overflow: ellipsis;
							overflow: hidden;
							white-space: nowrap;
						}
						.sale {
							font-size: 24rpx;
						}
					}
					.num-stock {
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666666;
						font-size: 24rpx;
					}
					.price-account {
						box-sizing: border-box;
						padding-top: 10rpx;
						font-size: 32rpx;
						display: flex;
						justify-content: space-between;
						align-items: center;
						.price {
							color: #e23a3a;
							font-weight: 500;
						}
						.accout {
							// background: #007AFF;
							width: 40%;
							display: flex;
							justify-content: space-between;
							align-items: center;
						}
					}
				}
			}
		}
	}

	.iptmain {
		margin: 30rpx 0;
		box-sizing: border-box;
		padding: 0rpx 30rpx;
	}
	.iptbox {
		background: #ffffff;
		border-bottom: 1rpx solid #e5e5e5;
		display: flex;
		justify-content: space-between;
		align-items: center;
		box-sizing: border-box;
		padding: 37rpx 15rpx;
		.text {
			font-size: 28rpx;
			text {
				color: #e23a3a;
			}
		}
		input {
			font-size: 26rpx;
			color: #999999;
			text-align: right;
		}
	}
	.last {
		border: none;
	}
	.tobtn {
		width: 100%;
		display: flex;
		justify-content: flex-end;
		background: #ffffff;
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		margin-top: 50rpx;
		.btnitem {
			margin-left: 30rpx;
			width: 30%;
			height: 60rpx;
			background: #2d8cf0;
			text-align: center;
			line-height: 60rpx;
			font-size: 24rpx;
			color: #ffffff;
		}
	}
}
</style>
