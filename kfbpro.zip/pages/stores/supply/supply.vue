<template>
	<view class="customer">
		<view class="search">
			<topback :topback="'供应'" :iscenter="false"></topback>
			<input type="text" value="" placeholder="搜索客户名称,联系人,手机号" />
		</view>
		<view class="tabs"><tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar></view>
		<view class="cuslist">
			<view class="cusli" v-for="(item, index) in cuslist" :key="index" @click="tocuritem(index, item)">
				<view class="label">平台供应商</view>
				<cusitem :curinfo="item"></cusitem>
			</view>
		</view>
		<view class="addcus" @click="toadd">新增线下供应商</view>
	</view>
</template>

<script>
import cusitem from '../../../components/listvertical/listvertical.vue';
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';

export default {
	data() {
		return {
			tabbarlist: ['收入/支出', '账单'],
			showindex: 0,
			cuslist: [
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978',
					address: '天府新谷'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				}
			]
		};
	},
	methods: {
		tocuritem(index, item) {
			console.log(index, item, 'e');
			uni.navigateTo({
				url: '../supplymain/supplymain'
			});
		},
		toadd(){
			uni.navigateTo({
				url:'../addsupply/addsupply'
			})
		},
		tonav(val) {
			this.showindex = val;
			console.log(this.showindex);
		}
	},
	components: {
		cusitem,
		topback,
		tabbar
	}
};
</script>

<style lang="less" scoped>
.customer {
	width: 100%;
	box-sizing: border-box;
	padding-top: 180rpx;
	.tabs {
		background: #ffffff;
		width: 100%;
		position: fixed;
		top: 100rpx;
		left: 0;
		z-index: 1111111;
	}
	.search {
		position: fixed;
		top: 0;
		left: 0;
		z-index: 1111111;
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		display: flex;
		justify-content: space-around;
		align-items: center;
		color: white;
		color: #ffffff;
		input {
			box-sizing: border-box;
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 20rpx;
			background: #ffffff;
			width: 70%;
			height: 55rpx;
			border-radius: 25rpx;
			padding: 0 25rpx;
			color: #b7b7b7;
			font-size: 24rpx;
		}
	}
	.cuslist {
		width: 100%;
		box-sizing: border-box;
		padding: 20rpx 20rpx;
		.cusli {
			box-sizing: border-box;
			padding: 15rpx 0rpx;
			background: #ffffff;
			border-bottom: 1rpx solid #e5e5e5;
			position: relative;
			.label {
				position: absolute;
				right: 0;
				top: 30rpx;
				width: 140rpx;
				text-align: center;
				line-height: 32rpx;
				height: 32rpx;
				background: #2d8cf0;
				border-radius: 8rpx;
				font-size: 24rpx;
				color: #ffffff;
			}
		}
	}
	.addcus {
		width: 80%;
		height: 100rpx;
		background: #2d8cf0;
		text-align: center;
		line-height: 100rpx;
		color: #ffffff;
		position: fixed;
		bottom: 20rpx;
		left: 50%;
		transform: translateX(-50%);
		box-shadow: 0px 4px 6px 0px rgba(250, 250, 250, 0.6);
	}
}
</style>
