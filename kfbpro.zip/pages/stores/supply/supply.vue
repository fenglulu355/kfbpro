<template>
	<view class="customer">
		<view class="headertop">
			<topback :topback="'供应'" :type="'one'" :isleft="true" :isbule="true" :isaddpic="true" @change="topchange"></topback>
			<view class="selectbox">
				<view class="tabs"><tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar></view>
			</view>
		</view>
		<view class="cuslist">
			<view class="cusli" v-for="(item, index) in cuslist" :key="index" @click="tocuritem(index, item)">
				<view class="label">平台供应商</view>
				<cusitem :curinfo="item"></cusitem>
			</view>
		</view>
		<view class="addcus" @click="toadd">新增线下供应商</view>
	</view>
</template>

<script>
import cusitem from '../../../components/listvertical/listvertical.vue';
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';

export default {
	data() {
		return {
			tabbarlist: ['收入/支出', '账单'],
			showindex: 0,
			cuslist: [
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978',
					address: '天府新谷'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				}
			],
			authorization: '',
			storeId: ''
		};
	},
	onLoad() {
		console.log('load');
		uni.getStorage({
			key: 'shopid',
			success: res => {
				console.log(res);
				this.storeId = res.data;
			}
		});
		uni.getStorage({
			key: 'atrztion',
			success: res => {
				this.authorization = res.data;
			}
		});
	},
	created() {
		console.log(this.authorization, 'q');
		this.requstlist();
	},
	methods: {
		requstlist() {
			let data = {
				supplierId: this.storeId,
				searchKeywords:'',
				type :1,
				pageNum: 1,
				pageSize: 10
			};
			console.log(data);
			this.$request(':8082/order/supplier/order/withPagingList', data, 'post', this.authorization).then(res => {
				console.log(res, 'a');
			});
		},
		tocuritem(index, item) {
			console.log(index, item, 'e');
			uni.navigateTo({
				url: '../supplymain/supplymain'
			});
		},
		toadd() {
			uni.navigateTo({
				url: '../addsupply/addsupply'
			});
		},
		tonav(val) {
			this.showindex = val;
			console.log(this.showindex);
		}
	},
	components: {
		cusitem,
		topback,
		tabbar
	}
};
</script>

<style lang="less" scoped>
.customer {
	width: 100%;
	box-sizing: border-box;
	padding-top: 180rpx;

	.headertop {
		background: #2d8cf0;
		position: fixed;
		width: 100%;
		z-index: 111;
		top: 0;
		left: 0;
		.bg {
			position: absolute;
			top: 0;
			z-index: 111;
			width: 100%;
			height: 200rpx;
		}
		.selectbox {
			margin-top: 100rpx;
			background: #ffffff;
			width: 100%;
			height: 100rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			position: relative;
			.pop {
				width: 30%;
				background: #ffffff;
				position: absolute;
				top: -10rpx;
				right: 40rpx;
				z-index: 11111111111111111;
				font-size: 28rpx;

				view {
					text-align: center;
					line-height: 60rpx;
				}
				.sel {
					color: #2d8cf0;
				}
			}
		}
		.tabs {
			width: 100%;
			// height: 100rpx;
			background: #ffffff;
		}
	}
	.cuslist {
		width: 100%;
		box-sizing: border-box;
		padding: 20rpx 20rpx;
		.cusli {
			box-sizing: border-box;
			padding: 15rpx 0rpx;
			background: #ffffff;
			border-bottom: 1rpx solid #e5e5e5;
			position: relative;
			.label {
				position: absolute;
				right: 0;
				top: 30rpx;
				width: 140rpx;
				text-align: center;
				line-height: 42rpx;
				height: 42rpx;
				background: #2d8cf0;
				border-radius: 8rpx;
				font-size: 24rpx;
				color: #ffffff;
			}
		}
	}
	.addcus {
		width: 80%;
		height: 100rpx;
		background: #2d8cf0;
		text-align: center;
		line-height: 100rpx;
		color: #ffffff;
		position: fixed;
		bottom: 20rpx;
		left: 50%;
		transform: translateX(-50%);
		box-shadow: 0px 4px 6px 0px rgba(250, 250, 250, 0.6);
	}
}
</style>
