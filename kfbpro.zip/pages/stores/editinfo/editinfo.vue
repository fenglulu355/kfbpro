<template>
	<view class="editinfo">
		<view class="top"><topback :type="'two'" :topback="'编辑客户资料'" :iscenter="true" :iswhite="true"></topback></view>
		<view class="content">
			<view class="box">
				<view class="iptbox">
					<view class="text">客户名称</view>
					<input type="text" value="" placeholder="卡链科技有限公司" />
				</view>
				<view class="iptbox">
					<view class="text">手机号</view>
					<input type="text" value="" placeholder="点击填写" />
				</view>
				<view class="iptbox">
					<view class="text">联系人</view>
					<input type="text" value="" placeholder="点击选择" />
				</view>
				<view class="iptbox last">
					<view class="text">地址</view>
					<input type="text" value="" placeholder="点击填写" />
				</view>
			</view>
			<view class="save">保存</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';

export default {
	data() {
		return {};
	},
	components: { topback }
};
</script>

<style lang="less" scoped>
.editinfo {
	width: 100%;
	background: #fafafa;
	position: relative;
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
	}
	.content {
		width: 100%;
		box-sizing: border-box;
		padding: 36rpx 30rpx;
		.box {
			border-radius: 5px 5px 0px 0px;
			box-shadow: 0px 4px 8px 0px rgba(250, 250, 250, 0.2);
			margin-bottom: 30rpx;
		}
		.iptbox {
			border-bottom: 1rpx solid #e5e5e5;
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 37rpx 0rpx;
			.text {
				font-size: 28rpx;
				text {
					color: #e23a3a;
				}
			}
			input {
				font-size: 26rpx;
				color: #999999;
				text-align: right;
			}
		}
		.last {
			border: none;
		}
		.save {
			width: 100%;
			height: 80rpx;
			background: #2d8cf0;
			text-align: center;
			line-height: 80rpx;
			color: #ffffff;
		}
	}
}
</style>
