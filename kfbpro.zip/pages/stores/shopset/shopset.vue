<template>
	<view class="shopset">
		<view class="top"><topback :topback="'门店设置'" :iscenter="true" :isbg="true"></topback></view>
		<view class="content">
			<view class="box tops">
				<view class="iptbox">
					<view class="text">门店头像</view>
					<input type="text" value="" placeholder="卡链科技有限公司" />
				</view>
				<view class="iptbox">
					<view class="text">门店名称</view>
					<input type="text" value="" placeholder="点击填写" />
				</view>
				<view class="iptbox">
					<view class="text">地区</view>
					<input type="text" value="" placeholder="点击选择" />
				</view>
				<view class="iptbox ">
					<view class="text">详细地址</view>
					<input type="text" value="" placeholder="点击填写" />
				</view>
				<view class="iptbox">
					<view class="text">联系人</view>
					<input type="text" value="" placeholder="点击填写" />
				</view>
				<view class="iptbox">
					<view class="text">手机号</view>
					<input type="text" value="" placeholder="点击选择" />
				</view>
				<view class="iptbox last zyyw">
					<view class="text">主营业务</view>
					<textarea class="textarea" value="" placeholder="发动机维修" />
					<view class="text">上述信息请联系BD经理修改</view>
				</view>
			</view>
			<view class="box bots">
				<view class="iptbox">
					<view class="text">营业时间</view>
					<input type="text" value="" placeholder="点击填写" />
				</view>
				<view class="iptbox">
					<view class="text">营业状态</view>
					<input type="text" value="" placeholder="点击选择" />
				</view>
				<view class="iptbox last zyyw">
					<view class="text">公告</view>
					<textarea class="textarea" value="" placeholder="发动机维修" />
				</view>
			</view>
			<view class="save">保存</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';

export default {
	data() {
		return {};
	},
	components: { topback }
};
</script>

<style lang="less" scoped>
.shopset {
	width: 100%;
	background: #fafafa;
	position: relative;
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
	}
	.content {
		width: 100%;
		box-sizing: border-box;
		padding: 36rpx 30rpx;
		.box {
			border-radius: 5px 5px 0px 0px;
			box-shadow: 0px 4px 8px 0px rgba(250, 250, 250, 0.2);
			margin-bottom: 30rpx;
			background: #ffffff;
			box-sizing: border-box;
			padding: 0rpx 15rpx;
		}

		.iptbox {
			border-bottom: 1rpx solid #e5e5e5;
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 37rpx 0rpx;
			.text {
				font-size: 28rpx;
				text {
					color: #e23a3a;
				}
			}
			input {
				font-size: 26rpx;
				color: #999999;
				text-align: right;
			}
		}
		.last {
			border: none;
		}
		.zyyw {
			display: block;
			.textarea {
				width: 100%;
				font-size: 26rpx;
				color: #999999;
				box-sizing: border-box;
				padding: 10rpx 0;
			}
			.texts {
				font-size: 26rpx;
				color: #999999;
				text-align: center;
			}
		}
		.save {
			width: 100%;
			height: 80rpx;
			background: #2d8cf0;
			text-align: center;
			line-height: 80rpx;
			color: #ffffff;
		}
	}
}
</style>
