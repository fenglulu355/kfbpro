<template>
	<view class="service">
		<view class="ser-head">
			<view class="search">
				<topback :topback="'服务'" :iscenter="false"></topback>
				<input type="text" value="" placeholder="搜索服务名称" />
			</view>
			<view class="selectbox"><Select @selected="getSelect" :options="options"></Select></view>
		</view>

		<view class="cuslist">
			<view class="cusli" 
			v-for="(item, index) in cuslist" 
			:key="index">
			 <cusitem :curinfo="item"  :type="'service'" @edit="edit"  @del="del"></cusitem></view>
		</view>
		<view class="addcus" @click="togroup">分组管理</view>
	</view>
</template>

<script>
import cusitem from '../../../components/listvertical/listvertical.vue';
import topback from '../../../components/topback/topback.vue';
import Select from '../../../components/Select/Select.vue';
export default {
	data() {
		return {
			options: [
				{
					name: '全部分组',
					code: '0'
				},
				{
					name: '零件',
					code: '1'
				},
				{
					name: '配件',
					code: '2'
				}
			],
			cuslist: [
				{
					name: '士大夫阿斯顿',
					price: '1',
					type: '清洗组',
					unit: '组'
				},
				{
					name: '士大夫阿斯顿',
					price: '56896',
					type: '清洗组',
					unit: '组'
				},
				{
					name: '士大夫阿斯顿',
					price: '56896',
					type: '清洗组',
					unit: '组'
				},
				{
					name: '士大夫阿斯顿',
					price: '56896',
					type: '清洗组',
					unit: '组'
				}
			]
		};
	},
	methods: {
		tocuritem(index, item) {
			console.log(index, item, 'e');
			uni.navigateTo({
				url: '../cusmain/cusmain'
			});
		},
		edit(val){
			console.log(val,'edit');
			uni.navigateTo({
				url:'../editserv/editserv'
			})
		},
		del(val){
			console.log(val,'del');
		},
		getSelect(val) {
			console.log(val);
		},
		togroup(){
			uni.navigateTo({
				url:'../editservgroup/editservgroup'
			})
		}
	},
	components: {
		cusitem,
		topback,
		Select
	}
};
</script>

<style lang="less" scoped>
.service {
	width: 100%;
	box-sizing: border-box;
	padding-top: 200rpx;
	.ser-head {
		width: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 1111111;
		.selectbox {
			height: 100rpx;
			background: #ffffff;
			line-height: 180rpx;
		}
	}
	.search {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		display: flex;
		justify-content: space-around;
		align-items: center;
		color: white;
		position: relative;
		color: #ffffff;
		input {
			box-sizing: border-box;
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 20rpx;
			background: #ffffff;
			width: 70%;
			height: 55rpx;
			border-radius: 25rpx;
			padding: 0 25rpx;
			color: #b7b7b7;
			font-size: 24rpx;
		}
	}
	.cuslist {
		width: 100%;
		box-sizing: border-box;
		padding: 30rpx 20rpx;
		.cusli {
			box-sizing: border-box;
			padding: 15rpx 0rpx;
			background: #ffffff;
			margin-bottom: 30rpx;
		}
	}
	.addcus {
		width: 80%;
		height: 100rpx;
		background: #2d8cf0;
		text-align: center;
		line-height: 100rpx;
		color: #ffffff;
		position: fixed;
		bottom: 20rpx;
		left: 50%;
		transform: translateX(-50%);
		box-shadow: 0px 4px 6px 0px rgba(250, 250, 250, 0.6);
	}
}
</style>
