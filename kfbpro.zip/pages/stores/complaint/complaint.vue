<template>
	<view class="editinfo">
		<view class="top"><topback :topback="'投诉建议'" :iscenter="true" :isbg="true"></topback></view>
		<view class="tabs"><tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar></view>
		<view class="content">
			<view class="cuscpl" v-show="showindex == 0">
				<view class="tabs"><tabbar :tabbarlist="mintab" :type="1" @change="mtonav"></tabbar></view>
				<view class="cpllist">
					<view class="cplli" v-for="(item, index) in cplli" :key="index" @click="tomain(item,index)">
						<view class="cp-top">
							<text class="time">{{ item.time }}</text>
							<text class="type" v-if="item.type == 0">待处理</text>
							<text class="type" v-if="item.type == 1">已回复</text>
						</view>
						<view class="contents" v-if="item.type == 0">{{ item.content }}</view>
						<view class="reply" v-if="item.type == 1">
							<view class="pmain">投诉详情：{{ item.content }}</view>
							<view class="prpl">回复：{{ item.reply }}</view>
						</view>
					</view>
				</view>
			</view>
			<view class="mine" v-show="showindex == 1">
				<view class="tabs"><tabbar :tabbarlist="mintab" :type="1" @change="mtonav"></tabbar></view>
			</view>

			<view class="save" @click="ispop = true">发起投诉</view>
		</view>
		<view class="addcpl" v-if="ispop">
			<textarea value="" placeholder="请输入投诉内容" />
			<view class="save" @click="tosend">提交</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';

export default {
	data() {
		return {
			ispop: false,
			showindex: 0,
			mshowindex: 0,
			tabbarlist: ['客户投诉', '我的投诉'],
			mintab: ['全部', '待处理', '已回复'],
			cplli: [
				{ time: '65+985+98', content: 'qweqwe阿三发射点发生发的发生大撒 ', type: 0 },
				{ time: '65+985+98', content: '大撒大撒撒撒旦案说', reply: '已联系商家处理', type: 1 },
				{ time: '65+985+98', content: '阿萨的任期为特人和和法规和风格化法国回复', type: 0 },
				{ time: '65+985+98', content: '风格和仔细擦拭多发点阿斯顿', reply: '已联系商家处理', type: 1 },
				{ time: '65+985+98', content: '啊实打实的', type: 0 },
				{ time: '65+985+98', content: '啊实打实的', reply: '已联系商家处理', type: 1 },
				{ time: '65+985+98', content: '阿斯顿阿斯顿', type: 0 },
				{ time: '65+985+98', content: '尔特', reply: '已联系商家处理', type: 1 },
				{ time: '65+985+98', content: '我去恶趣味', type: 0 },
				{ time: '65+985+98', content: '啊山豆根豆腐干', reply: '已联系商家处理', type: 1 }
			]
		};
	},
	onLoad() {},
	methods: {
		tosend() {
			this.ispop = false;
			setTimeout(function() {
				this.ispop = false;
			}, 500);
		},
		tonav(index) {
			this.showindex = index;
			console.log(index, 'index');
		},
		tomain() {
			uni.navigateTo({
				url: '../complaintmain/complaintmain'
			});
		},
		mtonav(index) {
			this.mshowindex = index;
			console.log(index, 'index');
		}
	},
	components: { topback, tabbar }
};
</script>

<style lang="less" scoped>
.editinfo {
	width: 100%;
	background: #fafafa;
	position: relative;
	box-sizing: border-box;
	padding: 100rpx 0rpx;
	.top {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 1111111;
	}
	.content {
		width: 100%;
		box-sizing: border-box;
		padding: 0rpx 30rpx;
		.tabs {
			box-sizing: border-box;
			padding: 40rpx 0;
		}
		.cpllist {
			width: 100%;
			.cplli {
				background: #ffffff;
				margin-bottom: 30rpx;
				color: #666666;
				.cp-top {
					display: flex;
					justify-content: space-between;
					align-items: center;
					box-sizing: border-box;
					padding: 20rpx 20rpx;
					border-bottom: 1rpx solid #e5e5e5;
					.time {
						font-size: 24rpx;
					}
					.type {
						font-size: 28rpx;
					}
				}
				.contents,
				.reply {
					min-height: 200rpx;
					box-sizing: border-box;
					padding: 30rpx 20rpx;
					font-size: 28rpx;
				}
			}
		}
	}
}
.addcpl {
	width: 100%;
	min-height: 2600rpx;
	box-sizing: border-box;
	padding: 30rpx 30rpx;
	background: #ffffff;
	position: fixed;
	top: 100rpx;
	left: 0;
	textarea {
		min-height: 800rpx;
		width: 100%;
		font-size: 26rpx;
		color: #999999;
	}
}
.save {
	margin-top: 80rpx;
	width: 100%;
	height: 80rpx;
	background: #2d8cf0;
	text-align: center;
	line-height: 80rpx;
	color: #ffffff;
}
</style>
