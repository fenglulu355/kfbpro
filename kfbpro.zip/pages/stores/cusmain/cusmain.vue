<template>
	<view class="cusmain">
		<view class="top">
			<topback :type="'two'"
			 :topback="'我的'" 
			 :iscenter="true"
			 :iswhite='true'
			 :istext="'删除'"
			 ></topback></view>
		<!-- 头部信息 -->
		<view
			class="headinfo"
			style="background: url(../../../static/images/bg.png);
				background-position: center;
				background-size: cover;
				background-repeat: no-repeat;"
		>
			<image src="../../../static/logo.png" mode=""></image>
			<view class="infos">
				<view class="title">顺丰公司</view>
				<view class="name-tle">
					<text class="name">刘经理</text>
					<text class="tel">548948979</text>
				</view>
				<!-- <view class="price">
					余额：
					<text>-500.00</text>
				</view> -->
			</view>
			<view class="edit" @click="topage('editinfo')">
				编辑
				<text>></text>
			</view>
		</view>
		<view class="pcontent">
			<!-- tabbar -->
			<tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar>
			<!-- 车辆 -->
			<view class="carlist" v-if="showindex == 0">
				<view class="carli" v-for="(item, index) in cuslist" :key="index"><caritem :curinfo="item"></caritem></view>
				<view class="tobtn">
					<view class="add box" @click="topage('addcar')">新增车辆</view>
					<view class="collection box">统一收款</view>
					<view class="reduction box">减免条款</view>
				</view>
			</view>
			<!-- 工单 -->
			<view class="goodsinfo" v-if="showindex == 1">
				<tabbar :tabbarlist="mintab" :type="1" @change="mtonav"></tabbar>
				<view class="orderlist">
					<view class="orderli" v-for="(item, index) in orderli" :key="index">
						<view class="o-top">
							<text class="time">{{ item.time }}</text>
							<text class="type">{{ item.type }}</text>
						</view>
						<view class="o-center">
							<view class="pic"><image src="../../../static/logo.png" mode=""></image></view>
							<view class="oc-center">
								<view class="name">
									<text class="names">{{ item.name }}</text>
									<image src="../../../static/images/otel.png" mode=""></image>
								</view>
								<view class="carnum">{{ item.carnum }}</view>
								<view class="incomes">
									<view class="income">
										预计收入
										<text class="text">￥{{ item.income }}</text>
									</view>
									<view class="toopen">
										展开
										<text>></text>
									</view>
								</view>
							</view>
						</view>
						<view class="o-bot">
							<view class="cancle">取消订单</view>
							<view class="accounts">结算</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 销售 -->
			<view class="sales" v-if="showindex == 2">
				<tabbar :tabbarlist="saletab" :type="1" @change="salestonav"></tabbar>
				<view class="salelist">
					<view class="saleli" v-for="(item, index) in saleli" :key="index"><goodsitem :goodsinfo="item" :types="1"></goodsitem></view>
				</view>
			</view>
		</view>
	</view>
</template>
 
<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '4../../../components/tabbar/tabbar.vue';
import caritem from '../../../components/listvertical/listvertical.vue';
import goodsitem from '../../../components/goodsitem/goodsitem';
export default {
	data() { 
		return {
			showindex: 0,
			mshowindex: 0,
			salesmindex: 0,
			tabbarlist: ['车辆', '工单', '销售'],
			mintab: ['全部', '进行中', '未结清', '已结清', '已作废'],
			saletab: ['全部', '未结清', '已结清'],
			orderli: [
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' },
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' }
			],
			saleli: [
				{
					shopname: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					address: '挨饿飞机恰尔即日起为案说法撒旦',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: '455774',
					nums: '15',
					type: '0'
				},
				{
					shopname: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					address: '挨饿飞机恰尔即日起为案说法撒旦',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: '455774',
					nums: '15',
					type: '1'
				}
			],
			cuslist: [
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				},
				{
					icon: '../../../static/logo.png',
					title: '十点十分我问',
					name: '士大夫阿斯顿',
					tel: '3216548978'
				}
			]
		};
	},
	components: { topback, tabbar, caritem, goodsitem },
	methods: {
		topage(url) {
			console.log(url);
			uni.navigateTo({
				url: `../${url}/${url}`
			});
		},
		tonav(index) {
			this.showindex = index;
			console.log(index, 'index');
		},
		mtonav(index) {
			this.mshowindex = index;
			console.log(index, 'index');
		},
		salestonav(index) {
			this.salesmindex = index;
			console.log(index, 'index');
		}
	}
};
</script>

<style lang="less" scoped>
.cusmain {
	width: 100%;
	height: 100%;
	position: relative;
	.top{
		width: 100%;
		position: absolute;
		top: 0;
	}
}
.pcontent {
	width: 100%;
	box-sizing: border-box;
	padding: 0 30rpx;
}
.tobtn {
	width: 100%;
	box-sizing: border-box;
	padding: 0 30rpx;
	position: fixed;
	bottom: 20rpx;
	left: 50%;
	transform: translateX(-50%);
	display: flex;
	justify-content: space-between;
	.box {
		width: 30%;
		height: 80rpx;
		line-height: 80rpx;
		color: #ffffff;
		font-size: 32rpx;
		text-align: center;
	}
	.add {
		background: #2d8cf0;
	}
	.collection {
		background: #e23a3a;
	}
	.reduction {
		background: #999999;
	}
}
.carlist {
	width: 100%;
	box-sizing: border-box;
	padding: 20rpx 0rpx;
	.carli {
		box-sizing: border-box;
		padding: 15rpx 0rpx;
		background: #ffffff;
		margin-bottom: 36rpx;
		width: 100%;
		height: 150rpx;
		background: #ffffff;
		border-radius: 5px;
		box-shadow: 0px 4px 8px 0px #fafafa;
	}
}
.sales {
	box-sizing: border-box;
	padding: 30rpx 0;
	.salelist {
		width: 100%;
		.saleli {
			box-sizing: border-box;
			padding: 25rpx 15rpx;
			background: #ffffff;
			margin: 25rpx 0;
		}
	}
}
.goodsinfo {
	box-sizing: border-box;
	padding: 30rpx 0;
	.orderlist {
		width: 100%;
		box-sizing: border-box;
		padding-top: 15rpx;
		.orderli {
			background: #ffffff;
			box-sizing: border-box;
			margin: 15rpx 0;
			padding: 30rpx 10rpx;
			color: #666666;
			.o-top {
				width: 100%;
				font-size: 24rpx;
				display: flex;
				justify-content: space-between;
				box-sizing: border-box;
				padding-bottom: 20rpx;
				border-bottom: 1rpx solid #e5e5e5;
			}
			.o-center {
				box-sizing: border-box;
				padding: 30rpx 0;
				display: flex;
				justify-content: space-between;
				.pic {
					width: 150rpx;
					height: 150rpx;
					image {
						width: 150rpx;
						height: 150rpx;
					}
				}
				.oc-center {
					width: 100%;
					box-sizing: border-box;
					padding-left: 30rpx;
					image {
						width: 50rpx;
						height: 50rpx;
					}
					.name,
					.incomes {
						display: flex;
						justify-content: space-between;
					}
					.name {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
					}
					.carnum {
						color: #666666;
						font-size: 26rpx;
						line-height: 60rpx;
					}
					.incomes {
						font-size: 28rpx;
						font-weight: 500;
						.text {
							color: #e23a3a;
							box-sizing: border-box;
							padding-left: 20rpx;
						}
					}
					.toopen {
						color: #b7b7b7;
						font-size: 24rpx;
					}
				}
			}
			.o-bot {
				width: 100%;
				display: flex;
				justify-content: flex-end;
				view {
					width: 30%;
					height: 60rpx;
					line-height: 60rpx;
					background: #cccccc;
					font-size: 32rpx;
					text-align: center;
					margin-left: 20rpx;
					color: #ffffff;
					border-radius: 5rpx;
				}
				.accounts {
					background: #2d8cf0;
				}
			}
		}
	}
}
.headinfo {
	width: 100%;
	height: 400rpx;
	display: flex;
	justify-content: space-between;
	align-items: center;
	box-sizing: border-box;
	padding: 50rpx 30rpx;
	color: #ffffff;
	image {
		width: 118rpx;
		height: 118rpx;
		border-radius: 50%;
	}
	.infos {
		width: 60%;
		box-sizing: border-box;
		padding-left: 20rpx;
		align-self: center;
		.title {
			font-size: 32rpx;
			box-sizing: border-box;
			padding-top: 20rpx;
		}
		.name-tle {
			box-sizing: border-box;
			padding-top: 20rpx;
			font-size: 28rpx;
		}

		.tel {
			font-size: 28rpx;
			box-sizing: border-box;
			padding-left: 20rpx;
		}
		.price {
			font-size: 30rpx;
			box-sizing: border-box;
			padding-top: 30rpx;
		}
	}
	.edit {
		align-self: center;
		font-size: 28rpx;
		text {
			box-sizing: border-box;
			padding-left: 20rpx;
		}
	}
}
</style>
