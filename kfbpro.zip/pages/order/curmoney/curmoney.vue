<template>
	<view class="cusmain">
		<view class="top"><topback :topback="'收款'" :iscenter="true"></topback></view>
		<view class="content">
			<view class="p-top">
				<image src="../../../static/images/icon_daishou.png" mode=""></image>
				<view class="price">+500.00</view>
				<view class="text">待收金额</view>
			</view>
		</view>
		<view class="money ">
			<view class="text">实收金额</view>
			<input type="text" value="" placeholder="5878" />
		</view>
		<view class="pay ">
			<view class="paybox">
				<text>支付方式</text>
				<text>
					选择支付方式
					<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
				</text>
			</view>
			<view class="note">
				<view class="text">收款备注</view>
				<textarea value="" placeholder="未填写收款备注" />
			</view>
		</view>
		<view class="onebtn"><view class="oneitem">确认收款</view></view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
export default {
	data() {
		return {};
	},
	components: { topback },
	methods: {
		tozdmain(item, index) {},
		toclc() {
			uni.navigateTo({
				url: '../curmoney/curmoney'
			});
		}
	}
};
</script>

<style lang="less" scoped>
.cusmain {
	width: 100%;
	height: 100%;

	position: relative;
	box-sizing: border-box;
	padding: 120rpx 0rpx;
	.top {
		background: #2d8cf0;
		width: 100%;
		position: absolute;
		top: 0;
	}
}
.content {
	background: #ffffff;
	text-align: center;
	box-sizing: border-box;
	padding: 30rpx 30rpx;
	image {
		width: 100rpx;
		height: 100rpx;
	}
	.price {
		font-size: 60rpx;
		color: #e23a3a;
	}
	.text {
		font-size: 24rpx;
		color: #999999;
	}
}
.money {
	background: #ffffff;
	margin: 30rpx 0;
	box-sizing: border-box;
	padding: 30rpx 30rpx;
	.text {
		font-size: 28rpx;
		color: #282828;
	}
	input {
		font-size: 60rpx;
		color: #282828;
		border-bottom: 1rpx solid #e5e5e5;
	}
}
.pay {
	background: #ffffff;
	margin: 30rpx 0;
	box-sizing: border-box;
	padding: 0rpx 30rpx;
	font-size: 28rpx;
	color: #666666;
	.paybox {
		box-sizing: border-box;
		padding: 30rpx 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: 1rpx solid #e5e5e5;
		image {
			margin-left: 20rpx;
			width: 11rpx;
			height: 22rpx;
		}
	}
	.note {
		box-sizing: border-box;
		padding: 30rpx 0;
		textarea {
			font-size: 24rpx;
			color: #b7b7b7;
			width: 100%;
			box-sizing: border-box;
			padding: 15rpx 15rpx;
		}
	}
}
.onebtn {

	box-sizing: border-box;
	padding: 0 30rpx;
	position: fixed;
	bottom: 30rpx;
	left: 0;
	width: 100%;
	height: 100rpx;
	text-align: center;
	.oneitem {
		background: #2d8cf0;
		color: #ffffff;
		font-size: 32rpx;
		width: 100%;
		height: 100%;
		line-height: 100rpx;
		text-align: center;
		border-radius: 5rpx;
	}
}
</style>
