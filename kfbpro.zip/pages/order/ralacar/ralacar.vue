item.km
<template>
	<view class="customer">
		<view class="search"><topback :topback="'关联车辆'" :iscenter="true"></topback></view>

		<view class="cuslist">
			<view class="infos" v-for="(item, index) in cuslist">
				<image src="../../../static/logo.png" mode=""></image>
				<view class="i-left">
					<view class="shopname">{{ item.name }}</view>

					<view class="carinfo">
						<text class="carnum">{{ item.carnum }}</text>
						<text class="km">{{ item.km }}km</text>
					</view>
				</view>
			</view>
		</view>
		<view class="addcus">跳过</view>
	</view>
</template>

<script>
import cusitem from '../../../components/listvertical/listvertical.vue';
import topback from '../../../components/topback/topback.vue';

export default {
	data() {
		return {
			cuslist: [
				{
					icon: '../../../static/logo.png',
					km: 54654,
					name: '士大夫阿斯顿',
					carnum: '川A659685'
				},
				{
					icon: '../../../static/logo.png',
					km: 54654,
					name: '士大夫阿斯顿',
					carnum: '川A659685'
				},
				{
					icon: '../../../static/logo.png',
					km: 54654,
					name: '士大夫阿斯顿',
					carnum: '川A659685'
				}
			]
		};
	},
	methods: {
		tocuritem(index, item) {
			console.log(index, item, 'e');
			uni.navigateTo({
				url: '../cusmain/cusmain'
			});
		}
	},
	components: {
		cusitem,
		topback
	}
};
</script>

<style lang="less" scoped>
.customer {
	width: 100%;
	.search {
		width: 100%;
		height: 100rpx;
		background: #2d8cf0;
		display: flex;
		justify-content: space-around;
		align-items: center;
		color: white;
		position: relative;
		color: #ffffff;
	}
	.cuslist {
		width: 100%;
		box-sizing: border-box;
		padding: 20rpx 20rpx;
		.infos {
			background: #ffffff;
			line-height: 55rpx;
			box-sizing: border-box;
			padding: 20rpx 30rpx;
			display: flex;
			justify-content: space-between;
			margin: 30rpx 0;
			image {
				width: 100rpx;
				height: 100rpx;
				border-radius: 50%;
			}
			.i-left {
				width: 82%;
				.shopname {
					font-size: 32rpx;
					color: #333333;
				}
				.names {
					.tel {
						padding-left: 20rpx;
					}
				}
				.adress {
					width: 100%;
					display: flex;
					justify-content: space-between;
					.text {
						width: 13%;
					}
					.main {
						width: 85%;
					}
				}
				.carinfo {
					display: flex;
					justify-content: space-between;
					font-size: 28rpx;
					color: #666666;
					text {
						width: 45%;
					}
				}
			}
		}
	}
	.addcus {
		width: 80%;
		height: 100rpx;
		background: #2d8cf0;
		text-align: center;
		line-height: 100rpx;
		color: #ffffff;
		position: fixed;
		bottom: 20rpx;
		left: 50%;
		transform: translateX(-50%);
		box-shadow: 0px 4px 6px 0px rgba(250, 250, 250, 0.6);
	}
}
</style>
