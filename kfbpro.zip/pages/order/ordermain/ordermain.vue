<template>
	<view class="salesmain">
		<view class="top"><topback :topback="'销售单结算'" :iscenter="true" :nums="headnum"></topback></view>
		<view class="tabs"><tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar></view>
		<!-- 基本信息 -->
		<view class="basicinfo" v-if="showindex == 0">
			<view class="infos" @click="tocus">
				<image src="../../../static/logo.png" mode=""></image>
				<view class="i-left">
					<view class="shopname">顺丰公司</view>
					<view class="names">
						<text class="name">刘经理</text>
						<text class="tel">1646878678</text>
					</view>
					<view class="adress">
						<text class="text">地址:</text>
						<text class="main">啊的破案看到看我打破空气污染皮卡丘陪我而哭泣欧派文库跑去欧文可请问哦</text>
					</view>
				</view>
			</view>
			<view class="infos" @click="toralacar">
				<image src="../../../static/logo.png" mode=""></image>
				<view class="i-left">
					<view class="shopname">顺丰公司</view>

					<view class="carinfo">
						<text class="carnum">川A245458</text>
						<text class="km">6546484KM</text>
					</view>
				</view>
			</view>
			<!-- 故障描述 -->
			<view class="fault">
				<view class="km">
					<text>当前里程数</text>
					<text>21654km</text>
				</view>
				<view class="f-desc">
					<text>故障描述</text>
					<input type="text" value="" placeholder="点击填写（不超过30字）" />
				</view>
				<view class="addpic">
					<image class="img" src="../../../static/images/addpic@2x.png" mode=""></image>
					<image class="img" src="../../../static/images/addpic@2x.png" mode=""></image>
					<image class="img" src="../../../static/images/addpic@2x.png" mode=""></image>
					<image class="img" src="../../../static/images/addpic@2x.png" mode=""></image>
					<image class="img" src="../../../static/images/addpic@2x.png" mode=""></image>
					<image class="img" src="../../../static/images/addpic@2x.png" mode=""></image>
				</view>
			</view>
			<view class="logistics">
				<view class="iptbox">
					<view class="text">负责人</view>
					<input type="text" value="" placeholder="张师傅、李师傅、王师傅" />
				</view>
				<view class="iptbox">
					<view class="text">实际工单时间</view>
					<input type="text" value="" placeholder="实际工单时间" />
				</view>
				<view class="iptbox last">
					<view class="text">预计完成时间</view>
					<input type="text" value="" placeholder="预计完成时间" />
				</view>
			</view>
			<view class="logistics">
				<view class="iptbox">
					<view class="text">开单人</view>
					<input type="text" value="" placeholder="开单人" />
				</view>
				<view class="iptbox last">
					<view class="text">开单时间</view>
					<input type="text" value="" placeholder="开单时间" />
				</view>
			</view>
			<view class="tobtn">
				<view class="price">￥634654</view>
				<view class="btnitem">取消订单</view>
				<view class="btnitem">结算</view>
			</view>
		</view>
		<!-- 服务与配件 -->
		<view class="fj-fw" v-if="showindex == 1">
			<view class="fwbox contents">
				<view class="title">
					<text>服务项目</text>
					<view class="addsevr">添加服务</view>
				</view>
				<view class="servlist">
					<view class="servli" v-for="(item, index) in servlist" :key="index">
						<view class="name">
							<text>{{ item.name }}</text>
							<image src="../../../static/images/del.png" mode=""></image>
						</view>

						<view class="accoutbox">
							<view class="accout">
								<view class="btns" @click="decrement(item, index)">-</view>
								<view class="cs">{{ item.cart_num }}</view>
								<view class="btns" @click="increment(item, index)" :disabled="item.cart_num >= item.stock">+</view>
								次
							</view>
							<view class="price">
								￥{{ item.price }}
								<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
							</view>
						</view>
					</view>
				</view>
				<view class="changetype">
					<text>分开结算/同一结算</text>
					<switch checked="true" @change="changeserv" />
				</view>
				<view class="allprice">
					<view class="xj">
						小计：
						<text>{{ fwtotal | showPrice }}</text>
					</view>
					<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
				</view>
			</view>
			<view class="pjcl contents">
				<view class="title">
					<text>配件材料</text>
					<view class="addsevr">添加配件</view>
				</view>
				<view class="servlist">
					<view class="servli" v-for="(item, index) in pjlist" :key="index">
						<view class="name">
							<text>{{ item.name }}</text>
							<image src="../../../static/images/del.png" mode=""></image>
						</view>
						<view class="minfos">
							<view class="type kfb" v-if="item.type == 0">卡服邦平台</view>
							<view class="type md" v-if="item.type == 1">门店自有</view>
							<text>{{ item.num }}</text>
						</view>
						<view class="accoutbox">
							<view class="accout">
								<view class="btns" @click="decrement(item, index)">-</view>
								<view class="cs">{{ item.cart_num }}</view>
								<view class="btns" @click="increment(item, index)">+</view>
								次
							</view>
							<view class="price">
								￥{{ item.price }}
								<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
							</view>
						</view>
					</view>
				</view>
				<view class="changetype">
					<text>分开结算/同一结算</text>
					<switch checked="true" @change="changeserv" />
				</view>
				<view class="allprice">
					<view class="xj">
						小计：
						<text>{{ pjtotal | showPrice }}</text>
					</view>
					<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
				</view>
			</view>

			<view class="tobtn">
				<view class="price">￥{{ pjtotal + fwtotal }}</view>
				<view class="btnitem" style="opacity: 0;"></view>
				<view class="btnitem">结算</view>
			</view>
		</view>
		<!-- 结算信息 -->
		<view class="accountinfo" v-if="showindex == 2">
			<view class="hasinfo" v-if="showindex == 1">
				<view class="infos">
					<view class="allprice item">
						<text>商品总额</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>运费</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>优惠金额</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>合计应付</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>当前待付金额</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>已付金额</text>
						<text>￥0</text>
					</view>
				</view>

				<view class="goodslist" v-if="origin != 'purchase'">
					<view class="listbox">
						<view class="saleli" v-for="(item, index) in saleli" :key="index">
							<view class="s-top">
								<text class="time">2020-05-06 15:34</text>
								<text class="zfb">支付宝</text>
								<text class="wx">微信支付</text>
							</view>
							<view class="mains">
								<view class="m-left"><image :src="item.img" mode=""></image></view>
								<view class="m-right">
									<view class="goodsname">{{ item.goodsname }}</view>
									<view class="type-sale">
										<text class="type">{{ item.goodsnum }}</text>
									</view>
									<view class="price-account">
										<text class="price">￥{{ item.price }}</text>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="tobtn">
					<view class="btnitem">添加收款</view>
					<view class="btnitem" v-if="origin == 'purchase'">取消订单</view>
				</view>
			</view>
			<view class="noinfo">
				<image src="../../../static/images/zanwushuju@2x.png" mode=""></image>
				<view class="text">工单暂未结算</view>
				<view class="tobtn">
					<view class="price">￥0.00</view>
					<view class="btnitem" style="opacity: 0;"></view>
					<view class="btnitem">结算</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '4../../../components/tabbar/tabbar.vue';

export default {
	data() {
		return {
			goodsinfo: [],
			origin: '',
			headnum: { text: '未结清', num: '65+99874' },
			tabbarlist: ['基本信息', '配件与服务', '结算信息'],
			showindex: 2,
			servlist: [
				{ name: '喷油嘴检测服务', price: 1, cart_num: 1, type: 0, num: '545887979' },
				{ name: '喷油嘴检测服务', price: 2, cart_num: 1, type: 0, num: '545887979' },
				{ name: '喷油嘴检测服务', price: 3, cart_num: 1, type: 1, num: '545887979' }
			],
			pjlist: [
				{ name: '喷油嘴检测服务', price: 4, cart_num: 1, type: 0, num: '545887979' },
				{ name: '喷油嘴检测服务', price: 5, cart_num: 1, type: 0, num: '545887979' },
				{ name: '喷油嘴检测服务', price: 6, cart_num: 1, type: 1, num: '545887979' }
			],
			saleli: [
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				}
			]
		};
	},
	computed: {
		fwtotal() {
			return this.servlist.reduce((previousValue, item) => previousValue + item.cart_num * item.price, 0);
		},
		pjtotal() {
			return this.pjlist.reduce((previousValue, item) => previousValue + item.cart_num * item.price, 0);
		}
	},
	onLoad(options) {
		this.origin = options.from;
		console.log(this.origin);
	},
	methods: {
		decrement(item, index) {
			if (item.cart_num <= 1) {
				return;
			} else {
				item.cart_num--;
			}
		},
		// 数量+
		increment(item, index) {
			item.cart_num++;
		},
		// 跳转至客户列表
		tocus() {
			uni.navigateTo({
				url: '../../stores/customer/customer'
			});
		},
		// 关联车辆
		toralacar() {
			uni.navigateTo({
				url: '../ralacar/ralacar'
			});
		},
		tonav(index) {
			this.showindex = index;
			console.log(index, 'index');
		}
	},
	filters: {
		showPrice(price) {
			return '￥' + price.toFixed(2);
		}
	},
	components: { topback, tabbar }
};
</script>

<style lang="less" scoped>
// 服务配件
.fj-fw {
	box-sizing: border-box;
	padding: 30rpx 30rpx 150rpx 30rpx;
	.contents {
		box-sizing: border-box;
		padding: 15rpx 15rpx;
		background: #ffffff;
		margin-bottom: 30rpx;
		.title {
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 15rpx 15rpx;
			font-size: 32rpx;
			color: #333333;
			border-bottom: 1rpx solid #e5e5e5;
			.addsevr {
				width: 200rpx;
				height: 60rpx;
				border: 1rpx solid #2d8cf0;
				border-radius: 30rpx;
				color: #2d8cf0;
				text-align: center;
				line-height: 60rpx;
			}
		}
		.minfos {
			font-size: 24rpx;
			color: #999999;
			display: flex;
			box-sizing: border-box;
			align-items: center;
			padding-top: 20rpx;
			.type {
				width: 150rpx;
				border-radius: 5rpx;
				height: 40rpx;
				line-height: 40rpx;
				text-align: center;
				margin-right: 20rpx;
			}
			.kfb {
				color: #ffa928;
				border: 1rpx solid #ffa928;
			}
			.md {
				color: #fa8364;
				border: 1rpx solid #fa8364;
			}
		}
		.servlist {
			box-sizing: border-box;
			padding: 30rpx 0rpx 0 0;
			.servli {
				background: #f7f7f7;
				margin-bottom: 20rpx;
				box-sizing: border-box;
				padding: 15rpx 15rpx;
				position: relative;
				.name {
					width: 100%;
					font-size: 28rpx;
					color: #333333;

					image {
						width: 60rpx;
						height: 63rpx;
						position: absolute;
						right: 0;
						top: 0;
					}
				}
				.accoutbox {
					display: flex;
					justify-content: space-between;
					align-items: center;
					box-sizing: border-box;
					padding: 20rpx 0;
					.accout {
						display: flex;
						justify-content: space-between;
						align-items: center;
						width: 30%;
						color: #999999;
						font-size: 26rpx;
						.cs {
							background: #e5e5e5;
							width: 40%;
							text-align: center;
							font-size: 24rpx;
							padding: 5rpx 0;
						}
						.btns {
							font-size: 40rpx;
						}
					}
					.price {
						color: #333333;
						font-size: 32rpx;

						image {
							padding-left: 20rpx;
							width: 12rpx;
							height: 21rpx;
						}
					}
				}
			}
		}
		.changetype {
			border-bottom: 1rpx solid #e5e5e5;
			color: #999999;
			font-size: 26rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			switch {
				transform: scale(0.5, 0.5);
			}
		}
		.allprice {
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 20rpx 0 10rpx 0;
			.xj {
				font-size: 26rpx;
				color: #999999;
				text {
					font-size: 32rpx;
					color: #333333;
				}
			}
			image {
				width: 11rpx;
				height: 21rpx;
			}
		}
	}
}
.iptbox {
	border-bottom: 1rpx solid #e5e5e5;
	display: flex;
	justify-content: space-between;
	align-items: center;
	box-sizing: border-box;
	padding: 37rpx 0rpx;
	.text {
		font-size: 28rpx;
		text {
			color: #e23a3a;
		}
	}
	input {
		font-size: 26rpx;
		color: #999999;
		text-align: right;
	}
}
.last {
	border: none;
}
.logistics {
	background: #ffffff;
	box-sizing: border-box;
	padding: 30rpx 30rpx;
	margin-top: 30rpx;
}
.salesmain {
	width: 100%;
	background: #fafafa;
	position: relative;
	box-sizing: border-box;
	// padding-top: 100rpx;
	.top {
		width: 100%;
		// height: 100rpx;
		background: #4d9df2;
		// position: fixed;
		// top: 0;
		// left: 0;
	}
	.tabs {
		background: #ffffff;
	}
	.basicinfo {
		width: 100%;
		font-size: 28rpx;
		color: #666666;
		box-sizing: border-box;
		padding: 0 30rpx 200rpx 30rpx;
		.addreli {
			color: #999999;
		}
		.infos {
			background: #ffffff;
			line-height: 55rpx;
			box-sizing: border-box;
			padding: 20rpx 30rpx;
			display: flex;
			justify-content: space-between;
			margin: 30rpx 0;
			image {
				width: 100rpx;
				height: 100rpx;
				border-radius: 50%;
			}
			.i-left {
				width: 82%;
				.shopname {
					font-size: 32rpx;
					color: #333333;
				}
				.names {
					.tel {
						padding-left: 20rpx;
					}
				}
				.adress {
					width: 100%;
					display: flex;
					justify-content: space-between;
					.text {
						width: 13%;
					}
					.main {
						width: 85%;
					}
				}
				.carinfo {
					display: flex;
					justify-content: space-between;
					text {
						width: 45%;
					}
				}
			}
		}
		.fault {
			background: #ffffff;
			box-sizing: border-box;
			padding: 0 15rpx;
			.km {
				display: flex;
				justify-content: space-between;
				color: #333333;
				box-sizing: border-box;
				padding: 20rpx 0;
				border-bottom: 1rpx solid #e5e5e5;
			}
			.f-desc {
				box-sizing: border-box;
				padding: 20rpx 0;
				border-bottom: 1rpx solid #e5e5e5;
				input {
					background: #F0AD4Es;
					width: 100%;
					font-size: 26rpx;

					margin-top: 10rpx;
				}
			}
			.addpic {
				width: 100%;
				box-sizing: border-box;
				padding: 20rpx 0;
				display: flex;
				justify-content: space-between;
				flex-wrap: wrap;
				align-items: center;
				.img {
					width: 31%;
					height: 200rpx;
					margin-bottom: 30rpx;
				}
			}
		}
	}

	.accountinfo {
		width: 100%;
.noinfo{
	text-align: center;
	box-sizing: border-box;
	padding: 50rpx 0;
	color: #999999;
	font-size: 32rpx;
	image{
		width: 450rpx;
		height: 450rpx;
	}
	
}
		.infos {
			width: 100%;
			box-sizing: border-box;
			padding: 30rpx 30rpx;
			.item {
				box-sizing: border-box;
				padding: 20rpx 0rpx;
				display: flex;
				justify-content: space-between;
				color: #666666;
				font-size: 28rpx;
				line-height: 50rpx;
			}
		}
		.goodslist {
			.s-top {
				width: 100%;
				display: flex;
				justify-content: space-between;
				font-size: 26rpx;
				color: #67c23a;
				border-bottom: 1rpx solid #e5e5e5;
				box-sizing: border-box;
				padding: 0 0 10rpx 0;
				.time {
					font-size: 24rpx;
					color: #666666;
				}
				.zfb {
					color: #2d8cf0;
				}
			}
			.mains {
				box-sizing: border-box;
				padding-top: 20rpx;
			}
		}
	}
	.goodslist {
		width: 100%;
		background: #ffffff;
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		.saleli {
			box-sizing: border-box;
			padding: 25rpx 15rpx;
			.mains {
				width: 100%;
				display: flex;
				justify-content: space-between;
				.m-left {
					width: 30%;
					image {
						width: 150rpx;
						height: 150rpx;
					}
				}
				.m-right {
					width: 69%;
					.goodsname {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
					}
					.type-sale {
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666666;
						box-sizing: border-box;
						padding: 10rpx 0 15rpx 0;
						.type {
							width: 60%;
							font-size: 26rpx;
							text-overflow: ellipsis;
							overflow: hidden;
							white-space: nowrap;
						}
						.sale {
							font-size: 24rpx;
						}
					}
					.num-stock {
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666666;
						font-size: 24rpx;
					}
					.price-account {
						box-sizing: border-box;
						padding-top: 10rpx;
						font-size: 32rpx;
						display: flex;
						justify-content: space-between;
						align-items: center;
						.price {
							color: #e23a3a;
							font-weight: 500;
						}
						.prices {
							color: #2d8cf0;
							font-weight: 500;
						}
						.carnum {
							font-size: 24rpx;
							color: #999999;
						}
						.accout {
							// background: #007AFF;
							width: 40%;
							display: flex;
							justify-content: space-between;
							align-items: center;
						}
					}
				}
			}
		}
	}

	.tobtn {
		width: 100%;
		display: flex;
		justify-content: flex-end;
		align-items: center;
		background: #ffffff;
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		// margin-top: 50rpx;
		position: fixed;
		bottom: 0rpx;
		left: 0;
		.price {
			font-size: 32rpx;
			color: #282828;
			width: 30%;
		}
		.btnitem {
			margin-left: 30rpx;
			width: 30%;
			height: 60rpx;
			background: #e23a3a;
			text-align: center;
			line-height: 60rpx;
			font-size: 24rpx;
			color: #ffffff;
		}
	}
}
</style>
