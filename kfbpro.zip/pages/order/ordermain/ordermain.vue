<template>
	<view class="salesmain">
		<view class="top"><topback :type="'two'" :topback="'销售单结算'" :iscenter="true" :istext="'投诉'" :iswhite="true" :nums="headnum" @change='tobacks'></topback></view>
		<view class="tabs"><tabbar :tabbarlist="tabbarlist" :type="0" @change="tonav"></tabbar></view>
		<!-- 基本信息 -->
		<view class="basicinfo" v-if="showindex == 0">
			<view class="infos" v-if="infos.orderContactsPerson">
				<image src="../../../static/images/kfb.png" mode=""></image>
				<view class="i-left">
					<view class="shopname">{{ infos.orderDriverUserName }}</view>
					<view class="names">
						<text class="name">{{ infos.orderContactsPerson }}</text>
						<text class="tel">{{ infos.orderContactsPhone }}</text>
					</view>
					<view class="adress">
						<text class="text">地址:</text>
						<text class="main">暂无地址</text>
					</view>
				</view>
			</view>
			<view class="addcar" v-else @click="tocus">
				<text class="text">选择客户</text>
				<image src="../../../static/images/add.png" mode=""></image>
			</view>
			<view class="infos" v-if="infos.orderModelsName">
				<image :src="'https://kfbnet2019.obs.cn-north-1.myhuaweicloud.com/brandImage/' + infos.orderModelsNameTwo + '.png'" mode=""></image>
				<view class="i-left">
					<view class="shopname">{{ infos.orderModelsName }}</view>
					<view class="carinfo">
						<text class="carnum">{{ infos.orderDriverUserCarPlateNumber }}</text>
						<text class="km">{{ infos.orderMileage }}KM</text>
					</view>
				</view>
			</view>
			<view class="addcar" v-else @click="toralacar">
				<text class="text">选择车辆</text>
				<image src="../../../static/images/add.png" mode=""></image>
			</view>
			<!-- 故障描述 -->
			<view class="fault">
				<view class="km">
					<text>当前里程数</text>
					<text>{{ infos.orderMileage }}km</text>
				</view>
				<view class="f-desc">
					<text>故障描述</text>
					<view class="des" v-if="online == false">{{ infos.orderFaultDescription }}</view>
					<input type="text" v-if="online == true" value="" v-model="gzdes" placeholder="点击填写（不超过30字）" />
				</view>
				<view class="addpic" v-if="online == false">
					<view class="box" v-for="(item, index) in infos.orderFaultImage" :key="index">
						<image class="img" :src="$baseUrl + '/orderFaultImage/' + item.imageUrl" mode=""></image>
					</view>
				</view>
				<view class="addpic" v-if="online == true">
					<!-- <input type="file" accept="image/*" value="" /> -->
					<view class="box" v-for="(item, index) in infos.orderFaultImage" :key="index">
						<image class="img" :src="'https://kfbnet2019.obs.cn-north-1.myhuaweicloud.com/orderFaultImage/' + item.imageUrl" mode=""></image>
					</view>
					<image class="img" @click="addpics" src="../../../static/images/addpic@2x.png" mode=""></image>
				</view>
			</view>
			<view class="logistics">
				<view class="iptbox">
					<view class="text">负责人</view>
					<view class="input" @click="tochangefzr('pickerfzr')">
						<view class="" v-for="(item, index) in infos.orderResponsible" :key="index">
							<text  v-html="item.orderResponsibleName ? item.orderResponsibleName : fzr"></text>
						</view>
					</view>
					<image v-if="online == true" @click="tochangefzr('pickerfzr')" class="more" src="../../../static/images/icon_shangla@2x.png" mode=""></image>
					<LbPicker ref="pickerfzr"  mode="selector" v-model="fzr" :list="fzrlist" @change="handleChange" @cancel="handleCancel" @confirm="Confirmfzr">></LbPicker>
				</view>
				<view class="iptbox">
					<view class="text">实际工单时间</view>
					<view class="input">{{ infos.orderAddTimeStr }}</view>
					<image v-if="online == true" @click="tochangesjtime('sjtime')" class="more" 
					src="../../../static/images/icon_shangla@2x.png" mode=""></image>
				</view>
				<view class="iptbox last">
					<view class="text">预计完成时间</view>
					<view class="input">{{ infos.orderEstimatedFinishTimeStr }}</view>
					<image v-if="online == true" class="more" src="../../../static/images/icon_shangla@2x.png" mode=""></image>
				</view>
				
			</view>
			<view class="logistics">
				<view class="iptbox">
					<view class="text">开单人</view>
					<view class="input">{{ infos.addUserName }}</view>
				</view>
				<view class="iptbox last">
					<view class="text">开单时间</view>
					<view class="input">{{ infos.orderAddTimeStr }}</view>
				</view>
				
			</view>
			<view class="tobtn">
				<view class="price">{{ infos.orderTotalAmount }}</view>
				<view class="btnitem">取消订单</view>
				<view class="btnitem">结算</view>
			</view>
		</view>
		<!-- 服务与配件 -->
		<view class="fj-fw" v-if="showindex == 1">
			<view class="fwbox contents">
				<view class="title">
					<text>服务项目</text>
					<view class="addsevr" @click="toaddsevr">添加服务</view>
				</view>
				<view class="servlist">
					<view class="servli" v-for="(item, index) in servlist" :key="index">
						<view class="name">
							<text>{{ item.serviceName }}</text>
							<image @click="delserv(item, index)" src="../../../static/images/del.png" mode=""></image>
						</view>
						<view class="accoutbox">
							<view class="accout">
								<view class="btns" @click="decrement(item, index)">-</view>
								<input :disabled="serchecked" type="number" value="" v-model="item.cart_num" class="cs" />
								<!-- <view class="cs">{{ item.cart_num }}</view> -->
								<view class="btns" @click="increment(item, index)">+</view>
								{{ item.serviceUnit }}
							</view>
							<view class="price">
								<input type="text" :disabled="serchecked" value="" v-model="item.serviceAmount" />
								<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
							</view>
						</view>
					</view>
				</view>
				<view class="changetype">
					<text>分开结算/同一结算</text>
					<switch :checked="serchecked" @change="changeserv" />
				</view>
				<view class="allprice">
					<view class="xj">
						小计：
						<text v-if="fwtotals == 0">{{ fwtotal | showPrice }}</text>
						<text v-else>{{ fwtotals | showPrice }}</text>
					</view>
					<image @click="tochangesevzj" src="../../../static/images/icon_shangla@2x.png" mode=""></image>
					<confirms :title="'修改总价'" :isshow="isservconfim" @change="changesevzj"></confirms>
				</view>
			</view>
			<view class="pjcl contents">
				<view class="title">
					<text>配件材料</text>
					<view class="addsevr" @click="toaddpj">添加配件</view>
				</view>
				<view class="servlist pjlist">
					<view class="servli" v-for="(item, index) in pjlist" :key="index">
						<view class="name">
							<text>{{ item.itemName }}</text>
							<image @click="delpj(item, index)" src="../../../static/images/del.png" mode=""></image>
						</view>
						<view class="minfos">
							<view class="type kfb" v-if="item.goodsType == 1">卡服邦平台</view>
							<view class="type md" v-if="item.goodsType == 2">门店自有</view>
							<text>{{ item.goodsCode }}</text>
						</view>
						<view class="accoutbox">
							<view class="accout">
								<view class="btns" @click="decrement(item, index)">-</view>
								<input :disabled="pjchecked" type="text" value="" v-model="item.itemNumber" class="cs" />
								<!-- <view class="cs">{{ item.cart_num }}</view> -->
								<view class="btns" @click="increment(item, index)">+</view>
								<!-- 次 -->
							</view>
							<view class="price">
								<input type="text" :disabled="pjchecked" value="" v-model="item.itemUnitPrice" />
								<image src="../../../static/images/icon_shangla@2x.png" mode=""></image>
							</view>
						</view>
					</view>
				</view>
				<view class="changetype">
					<text>分开结算/同一结算</text>
					<switch :checked="pjchecked" @change="changepj" />
				</view>
				<view class="allprice">
					<view class="xj">
						小计：
						<text v-if="pjtotals == 0">{{ pjtotal | showPrice }}</text>
						<text v-else>{{ pjtotals | showPrice }}</text>
					</view>
					<image @click="tochangepjzj" src="../../../static/images/icon_shangla@2x.png" mode=""></image>
					<confirms :title="'修改总价'" :isshow="ispjconfim" @change="changepjzj"></confirms>
				</view>
			</view>

			<view class="tobtn">
				<view class="price" v-show="fwtotals == 0 && pjtotals == 0">￥{{ pjtotal + fwtotal }}</view>
				<view class="price" v-show="fwtotals != 0 && pjtotals == 0">￥{{ pjtotal + fwtotals }}</view>
				<view class="price" v-show="fwtotals == 0 && pjtotals != 0">￥{{ pjtotals + fwtotal }}</view>
				<view class="price" v-show="fwtotals != 0 && pjtotals != 0">￥{{ pjtotals + fwtotals }}</view>
				<view class="btnitem" style="opacity: 0;"></view>
				<view class="btnitem" @click="tosendpf">结算</view>
			</view>
		</view>
		<!-- 结算信息 -->
		<view class="accountinfo" v-if="showindex == 2">
			<view class="noinfo" v-if="orderStatus == 1">
				<image src="../../../static/images/zanwushuju@2x.png" mode=""></image>
				<view class="text">工单暂未结算</view>
				<view class="tobtn">
					<view class="price" v-show="fwtotals == 0 && pjtotals == 0">￥{{ pjtotal + fwtotal }}</view>
					<view class="price" v-show="fwtotals != 0 && pjtotals == 0">￥{{ pjtotal + fwtotals }}</view>
					<view class="price" v-show="fwtotals == 0 && pjtotals != 0">￥{{ pjtotals + fwtotal }}</view>
					<view class="price" v-show="fwtotals != 0 && pjtotals != 0">￥{{ pjtotals + fwtotals }}</view>
					<view class="btnitem" style="opacity: 0;"></view>
					<view class="btnitem" @click="tosendpf">结算</view>
				</view>
			</view>
			<view class="hasinfo" v-else>
				<view class="infos">
					<view class="allprice item">
						<text>商品总额</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>运费</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>优惠金额</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>合计应付</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>当前待付金额</text>
						<text>￥35465468</text>
					</view>
					<view class="allprice item">
						<text>已付金额</text>
						<text>￥0</text>
					</view>
				</view>

				<view class="goodslist" v-if="origin != 'purchase'">
					<view class="listbox">
						<view class="saleli" v-for="(item, index) in saleli" :key="index">
							<view class="s-top">
								<text class="time">2020-05-06 15:34</text>
								<text class="zfb">支付宝</text>
								<text class="wx">微信支付</text>
							</view>
							<view class="mains">
								<view class="m-left"><image :src="item.img" mode=""></image></view>
								<view class="m-right">
									<view class="goodsname">{{ item.goodsname }}</view>
									<view class="type-sale">
										<text class="type">{{ item.goodsnum }}</text>
									</view>
									<view class="price-account">
										<text class="price">￥{{ item.price }}</text>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="tobtn">
					<view class="btnitem">添加收款</view>
					<view class="btnitem" v-if="origin == 'purchase'">取消订单</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';
import uploadImg from '../../../components/amazarashi-uploadimg/uploadImg.vue';
import confirms from '../../../components/confirmbox/confirmbox.vue';
import LbPicker from '../../../components/lb-picker/index.vue';
import minpicker from '../../../components/min-picker/min-picker.vue';
import minpopup from '../../../components/min-picker/min-popup.vue';



export default {
	data() {
		return {
			startTimes: [2010, 6, 1],
			endTime: 2046,
					show1: false,
			goodsinfo: [],
			origin: '',
			headnum: {},
			tabbarlist: ['基本信息', '配件与服务', '结算信息'],
			showindex: 0,
			servlist: [],
			pjlist: [],
			saleli: [
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 2,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				},
				{
					goodstype: '哦阿斯蒂芬今晚i吉尔菲我就二分',
					goodsname: '佛寺饥饿反',
					goodsnum: 'aisjhfdia',
					price: 1,
					sale: '15',
					stock: '54',
					img: '../../../static/logo.png',
					cart_num: 1
				}
			],
			authorization: '',
			orderid: '',
			shopid: '',
			infos: [],
			online: false,
			piclist: [],
			src: '',
			serchecked: false,
			sertype: 1,
			pjchecked: false,
			pjtype: 1,
			isservconfim: false,
			ispjconfim: false,
			fwtotals: 0,
			pjtotals: 0,
			serfoucs: null,
			orderStatus: null,
			gzdes: '', //故障描述
			fzr: '暂无负责人',
			fzrlist: []
		};
	},
	computed: {
		...mapState(['orderinfo', 'serverlist']),
		fwtotal: {
			get: function() {
				return this.servlist.reduce((previousValue, item) => previousValue + item.cart_num * item.serviceAmount, 0);
			},
			set: function(a) {
				this.fwtotals = a;
			}
		},
		pjtotal: {
			get: function() {
				return this.pjlist.reduce((previousValue, item) => previousValue + item.itemNumber * item.itemUnitPrice, 0);
			},
			set: function(a) {
				this.pjtotals = a;
			}
		}
	},
	onLoad(options) {
		var that = this;
		let datas = uni.getStorageSync('ordermaininfo');
		this.authorization = uni.getStorageSync('atrztion');
		this.shopid = uni.getStorageSync('shopid');
		this.orderid = datas.orderId;
		this.orderStatus = datas.orderStatus;
		if(options.showindex){
			this.showindex=options.showindex
		}else{
			this.showindex=0
		}
		if (datas.orderStatus == 1) {
			this.headnum.text = '进行中';
			this.headnum.num = datas.orderCode;
			this.online = true;
			this.request(this.orderid);
			this.requestfzr();
		}
		console.log(this.servlist, 'servlist');
	},
	created() {},
	methods: {
		tobacks(e){
			console.log(e);
			if(e=='back'){
				uni.switchTab({
					url:'../ohome/ohome'
				})
			}
		},
		...mapMutations(['SET_ORDERINFO', 'SET_SERVERLIST']),
		// 请求数据
		request(orderid) {
			var that = this;
			this.$request('/order/store/order/infobypk/' + orderid, '', 'get', this.authorization).then(res => {
				this.infos = res.datas;
				this.SET_ORDERINFO(this.infos);
				this.gzdes = res.datas.orderFaultDescription;
				this.gzpiclist = res.datas.orderFaultImage;

				console.log(this.orderinfo, 'orderinfo');
				console.log(res.datas);
				let servarr = that.infos.orderServiceItems.projectDetails,
					servlen = servarr.length,
					pjarr = that.infos.orderReplacementParts.projectDetails,
					pjlen = pjarr.length,
					list,
					i,
					j,
					m,
					n;
				if (servlen != 0) {
					console.log(1, '\koko');
				} else {
					this.servlist = this.serverlist;
				}
				// // 服务项目
				// this.servlist = servarr;
				// 配件
				// this.pjlist = pjarr;
				console.log(this.serverlist, 'this.servlist ');
				// if (service) {
				// 	service.forEach(res => {
				// 		console.log(res, 'aaaa');
				// 		let i,
				// 			arr = that.infos.orderServiceItems.projectDetails,
				// 			length = arr.length;
				// 		if (length != 0) {
				// 			for (i = 0; i < length; i++) {
				// 				if (res.itemId == arr[i].itemId) {
				// 					arr[i].itemNumber++;
				// 				} else {
				// 					arr.push(res);
				// 				}
				// 			}
				// 		} else {
				// 			arr.push(res);
				// 		}

				// 		that.infos.orderServiceItems.projectDetails.push(res);
				// 	});
				// }
				// if (fittings) {
				// 	fittings.forEach(res => {
				// 		console.log(res, 'bbb');
				// 		let i,
				// 			arr = that.infos.orderReplacementParts.projectDetails,
				// 			length = arr.length;
				// 		if (length != 0) {
				// 			for (i = 0; i < length; i++) {
				// 				if (res.itemId == arr[i].itemId) {
				// 					arr[i].itemNumber++;
				// 				} else {
				// 					arr.push(res);
				// 				}
				// 			}
				// 		} else {
				// 			arr.push(res);
				// 		}
				// 		console.log(that.infos.orderReplacementParts.projectDetails, 'adsdfa');
				// 		// that.infos.orderReplacementParts.projectDetails;
				// 	});
				// }
			});
		},
		// 上传图片
		addpics() {
			console.log(1);
			uni.chooseImage({
				count: 1,
				success: res => {
					this.piclist = res.tempFilePaths;
					console.log(res);

					uni.uploadFile({
						url: 'http://114.116.28.111:8084/system/file/upload',
						filePath: res.tempFilePaths[0],
						name: 'file',
						formData: {
							// 'file':res.tempFilePaths[0],
							fileStorageFolder: 'orderFaultImage'
						},
						header: { authorization: this.authorization, 'Content-Type': 'multipart/form-data' },
						success: function(uploadFileRes) {
							console.log(uploadFileRes.data);
						}
					});
				}
			});
			// console.log(this.piclist);
			// uni.uploadFile({
			// 	url:this.$baseUrl+'/system/file/upload', //仅为示例，非真实的接口地址
			// 	files: [],

			// 	success: res => {
			// 		console.log(res);
			// 	}
			// });
		},

		// 显示负责人
		tochangefzr(name) {
			var that = this;
			setTimeout(function() {
				that.$refs[name].show();
			}, 200);
		},
		// 请求负责人
		requestfzr() {
			var that = this;
			this.$request('/organization/user/store/staff/withPagingList', { storeId: this.shopid, userStatus: 1 }, 'post', this.authorization, '').then(res => {
				console.log(res.datas);
				for (var i = 0, length = res.datas.length; i < length; i++) {
					let obj = {};
					(obj.label = res.datas[i].userName), (obj.value = res.datas[i].userId);
					that.fzrlist.push(obj);
				}
			});
		},
		handleChange(item) {
			// this.type = item;
			console.log(item);
		},
		handleCancel(item) {
			// this.type = item;
		},
		// 修改工单负责人和完成时间
		changeorderbasic(data) {
			this.$request('/order/store/order/update', data, 'PUT', this.authorization, 'application/json').then(res => {
				console.log(res);
				if (res.kfbCode == '200') {
					uni.showToast({
						title: '修改成功'
					});
				}
			});
		},
		//选择负责人
		Confirmfzr(item) {
			console.log(item, 'dfsf');
			this. infos.orderResponsible[0].orderResponsibleName = item.item.label;
			this.fzr=item.item.label;
			let data = { storeId: this.shopid, orderId: this.orderid, listResponsible: [{ userId: item.item.value, userName: item.item.label }] };
			this.changeorderbasic(data);
		},
		// 显示实际工单时间
		tochangesjtime(name){
			this.show1 = true;
			
		},
		
		decrement(item, index) {
			if (item.itemNumber <= 1) {
				return;
			} else {
				item.itemNumber;
			}
		},
		// 数量+
		increment(item, index) {
			item.itemNumber++;
		},
		// 跳转至添加服务
		toaddsevr(infos) {
			// this.tosendpf();
			setTimeout(function() {
				uni.navigateTo({
					url: '../../stores/service/service?origin=order'
				});
			}, 500);
		},
		// 删除服务项目
		delserv(item, index) {
			this.servlist.splice(index, 1);
		},
		// 是否统一结算服务
		changeserv(e) {
			console.log(e.target.value);
			this.serchecked = e.target.value;
			if (this.serchecked == false) {
				this.fwtotals = 0;
				this.sertype = 1;
			} else {
				this.sertype = 2;
			}
		},
		// 显示修改服务总价框框
		tochangesevzj() {
			if (this.serchecked == true) {
				this.isservconfim = true;
			} else {
				uni.showToast({
					icon: 'none',
					title: '请选择统一结算'
				});
			}
		},
		// 修改服务总价e
		changesevzj(e) {
			console.log(e, 'a');
			if (e == 'cancle') {
				this.isservconfim = false;
			} else {
				this.fwtotal = Number(e);
				this.isservconfim = false;
			}
		},
		// 跳转至添加配件
		toaddpj() {
			console.log(1);
			this.tosendpf();
			setTimeout(function() {
				uni.navigateTo({
					url: '../addpj/addpj?origin=order'
				});
			}, 500);
		},
		// 删除配件项目
		delpj(item, index) {
			this.pjlist.splice(index, 1);
		},
		// 是否统一结算配件
		changepj(e) {
			console.log(e.target.value);
			this.pjchecked = e.target.value;
			if (this.pjchecked == false) {
				this.pjtotals = 0;
				this.pjtype = 1;
			} else {
				this.pjtype = 2;
			}
		},
		// 显示修改配件总价框框
		tochangepjzj() {
			if (this.pjchecked == true) {
				this.ispjconfim = true;
			} else {
				uni.showToast({
					icon: 'none',
					title: '请选择统一结算'
				});
			}
		},
		// 修改配件总价e
		changepjzj(e) {
			console.log(e, 'pj');
			if (e == 'cancle') {
				this.ispjconfim = false;
			} else {
				this.pjtotal = Number(e);
				this.ispjconfim = false;
			}
		},
		// 结算配件和服务
		tosendpf() {
			this.accout();
		},

		// 结算函数
		accout() {
			let fwprice,
				pjprice,
				that = this;
			this.fwtotals == 0 ? (fwprice = this.fwtotal) : (fwprice = this.fwtotals);
			this.pjtotals == 0 ? (pjprice = this.pjtotal) : (pjprice = this.pjtotals);
			for (let i = 0, length = this.pjlist.length; i < length; i++) {
				delete this.pjlist[i].goodsCode;
			}
			var fromData = {
				orderId: this.orderid, //订单id
				storeId: this.shopid,
				orderGoodsUpdateInfo: {
					detailStageAmountType: this.pjtype,
					orderGoodsItems: this.pjlist,
					detailStageAmount: pjprice
				},
				orderServiceUpdateInfo: {
					detailStageAmountType: this.sertype,
					orderServiceItems: this.servlist,
					detailStageAmount: fwprice
				}
			};
			console.log(fromData);
			this.$request('/order/store/order/goods/unite/update', fromData, 'put', this.authorization, 'application/json')
				.then(res => {
					console.log(res);
					if (res.kfbCode == '200') {
						uni.showToast({
							title: '保存成功'
						});
						uni.removeStorageSync('fittings');
						uni.removeStorageSync('service');
						setTimeout(function() {
							uni.navigateTo({
								url: '../collection/collection?orderId=' + that.orderid + '&sname=' + that.orderinfo.storeName + '&pj=' + pjprice + '&fw=' + fwprice
							});
						}, 500);
					} else {
						uni.showToast({
							icon: 'none',
							title: 'code:' + res.kfbCode + res.kfbErrorMsg
						});
					}
				})
				.catch(res => {
					console.log(res, 'cath');
				});
		},
		// 跳转至客户列表

		tocus() {
			uni.navigateTo({
				url: '../../stores/customer/customer?from=order'
			});
		},
		// 关联车辆
		toralacar() {
			uni.navigateTo({
				url: '../ralacar/ralacar?driverId=' + this.orderinfo.orderDriverUserId + '&from=order'
			});
		},
		tonav(index) {
			this.showindex = index;
			console.log(index, 'index');
		}
	},
	filters: {
		showPrice(price) {
			return '￥' + price.toFixed(2);
		}
	},
	components: { confirms,	minpopup,
		minpicker , topback, tabbar, uploadImg, LbPicker }
};
</script>

<style lang="less" scoped>
// 服务配件
.fj-fw {
	box-sizing: border-box;
	padding: 30rpx 30rpx 150rpx 30rpx;
	.contents {
		box-sizing: border-box;
		padding: 15rpx 15rpx;
		background: #ffffff;
		margin-bottom: 30rpx;
		.title {
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 15rpx 15rpx;
			font-size: 32rpx;
			color: #333333;
			border-bottom: 1rpx solid #e5e5e5;
			.addsevr {
				width: 200rpx;
				height: 60rpx;
				border: 1rpx solid #2d8cf0;
				border-radius: 30rpx;
				color: #2d8cf0;
				text-align: center;
				line-height: 60rpx;
			}
		}
		.minfos {
			font-size: 24rpx;
			color: #999999;
			display: flex;
			box-sizing: border-box;
			align-items: center;
			padding-top: 20rpx;
			.type {
				width: 150rpx;
				border-radius: 5rpx;
				height: 40rpx;
				line-height: 40rpx;
				text-align: center;
				margin-right: 20rpx;
			}
			.kfb {
				color: #ffa928;
				border: 1rpx solid #ffa928;
			}
			.md {
				color: #fa8364;
				border: 1rpx solid #fa8364;
			}
		}
		.servlist {
			box-sizing: border-box;
			padding: 30rpx 0rpx 0 0;
			.servli {
				background: #f7f7f7;
				margin-bottom: 20rpx;
				box-sizing: border-box;
				padding: 15rpx 15rpx;
				position: relative;
				.name {
					width: 100%;
					font-size: 28rpx;
					color: #333333;

					image {
						width: 60rpx;
						height: 63rpx;
						position: absolute;
						right: 0;
						top: 0;
					}
				}
				.accoutbox {
					display: flex;
					justify-content: space-between;
					align-items: center;
					box-sizing: border-box;
					padding: 20rpx 0;
					.accout {
						display: flex;
						justify-content: space-between;
						align-items: center;
						width: 30%;
						color: #999999;
						font-size: 26rpx;
						.cs {
							background: #e5e5e5;
							width: 40%;
							text-align: center;
							font-size: 24rpx;
							padding: 5rpx 0;
						}
						.btns {
							font-size: 40rpx;
						}
					}
					.price {
						width: 60%;

						color: #333333;
						font-size: 32rpx;
						display: flex;
						justify-content: space-between;
						align-items: center;
						input {
							width: 90%;
							color: #333333;
							font-size: 32rpx;
							text-align: right;
						}
						image {
							padding-left: 20rpx;
							width: 12rpx;
							height: 21rpx;
						}
					}
				}
			}
		}
		.changetype {
			border-bottom: 1rpx solid #e5e5e5;
			color: #999999;
			font-size: 26rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			switch {
				transform: scale(0.5, 0.5);
			}
		}
		.allprice {
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 20rpx 0 10rpx 0;
			.xj {
				font-size: 26rpx;
				color: #999999;
				text {
					font-size: 32rpx;
					color: #333333;
				}
			}
			image {
				width: 11rpx;
				height: 21rpx;
			}
		}
	}
}
.iptbox {
	border-bottom: 1rpx solid #e5e5e5;
	display: flex;
	justify-content: space-between;
	align-items: center;
	box-sizing: border-box;
	padding: 37rpx 0rpx;
	.text {
		width: 32%;
		font-size: 28rpx;
		text {
			color: #e23a3a;
		}
	}
	.input,
	input {
		font-size: 26rpx;
		color: #999999;
		text-align: right;
	}
	.input {
		width: 60%;
		display: flex;
		justify-content: flex-end;
		text {
			padding-left: 10rpx;
		}
	}
	.more {
		padding-left: 10rpx;
		width: 11rpx;
		height: 21rpx;
	}
}
.last {
	border: none;
}
.logistics {
	background: #ffffff;
	box-sizing: border-box;
	padding: 30rpx 30rpx;
	margin-top: 30rpx;
}
.salesmain {
	width: 100%;
	background: #fafafa;
	position: relative;

	.top {
		width: 100%;
		height: 300rpx;
		background: #4d9df2;
		// position: fixed;
		// top: 0;
		// left: 0;
	}
	.tabs {
		background: #ffffff;
	}
	.basicinfo {
		width: 100%;
		font-size: 28rpx;
		color: #666666;
		box-sizing: border-box;
		padding: 0rpx 30rpx 200rpx 30rpx;
		.addreli {
			color: #999999;
		}
		.addcar {
			background: #ffffff;
			line-height: 55rpx;
			box-sizing: border-box;
			padding: 50rpx 30rpx;
			display: flex;
			justify-content: space-between;
			margin: 30rpx 0;
			image {
				margin: 0 auto;
				width: 100rpx;
				height: 100rpx;
			}
		}
		.infos {
			background: #ffffff;
			line-height: 55rpx;
			box-sizing: border-box;
			padding: 20rpx 30rpx;
			display: flex;
			justify-content: space-between;
			margin: 30rpx 0;
			image {
				width: 100rpx;
				height: 100rpx;
				border-radius: 50%;
			}
			.i-left {
				width: 82%;
				.shopname {
					font-size: 32rpx;
					color: #333333;
				}
				.names {
					.tel {
						padding-left: 20rpx;
					}
				}
				.adress {
					width: 100%;
					display: flex;
					justify-content: space-between;
					.text {
						width: 13%;
					}
					.main {
						width: 85%;
					}
				}
				.carinfo {
					display: flex;
					justify-content: space-between;
					text {
						width: 45%;
					}
					.km {
						text-align: right;
					}
				}
			}
		}
		.fault {
			background: #ffffff;
			box-sizing: border-box;
			padding: 0 15rpx;
			.km {
				display: flex;
				justify-content: space-between;
				color: #333333;
				box-sizing: border-box;
				padding: 20rpx 0;
				border-bottom: 1rpx solid #e5e5e5;
			}
			.f-desc {
				box-sizing: border-box;
				padding: 20rpx 0;
				border-bottom: 1rpx solid #e5e5e5;
				.des,
				input {
					background: #F0AD4Es;
					width: 100%;
					font-size: 26rpx;
					margin-top: 10rpx;
				}
			}
			.addpic {
				width: 100%;
				box-sizing: border-box;
				padding: 20rpx 0;
				display: flex;
				justify-content: space-between;
				flex-wrap: wrap;
				align-items: center;
				.img {
					width: 31%;
					height: 200rpx;
					margin-bottom: 30rpx;
				}
			}
		}
	}

	.accountinfo {
		width: 100%;
		.noinfo {
			text-align: center;
			box-sizing: border-box;
			padding: 50rpx 0;
			color: #999999;
			font-size: 32rpx;
			image {
				width: 450rpx;
				height: 450rpx;
			}
		}
		.infos {
			width: 100%;
			box-sizing: border-box;
			padding: 30rpx 30rpx;
			.item {
				box-sizing: border-box;
				padding: 20rpx 0rpx;
				display: flex;
				justify-content: space-between;
				color: #666666;
				font-size: 28rpx;
				line-height: 50rpx;
			}
		}
		.goodslist {
			.s-top {
				width: 100%;
				display: flex;
				justify-content: space-between;
				font-size: 26rpx;
				color: #67c23a;
				border-bottom: 1rpx solid #e5e5e5;
				box-sizing: border-box;
				padding: 0 0 10rpx 0;
				.time {
					font-size: 24rpx;
					color: #666666;
				}
				.zfb {
					color: #2d8cf0;
				}
			}
			.mains {
				box-sizing: border-box;
				padding-top: 20rpx;
			}
		}
	}
	.goodslist {
		width: 100%;
		background: #ffffff;
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		.saleli {
			box-sizing: border-box;
			padding: 25rpx 15rpx;
			.mains {
				width: 100%;
				display: flex;
				justify-content: space-between;
				.m-left {
					width: 30%;
					image {
						width: 150rpx;
						height: 150rpx;
					}
				}
				.m-right {
					width: 69%;
					.goodsname {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
					}
					.type-sale {
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666666;
						box-sizing: border-box;
						padding: 10rpx 0 15rpx 0;
						.type {
							width: 60%;
							font-size: 26rpx;
							text-overflow: ellipsis;
							overflow: hidden;
							white-space: nowrap;
						}
						.sale {
							font-size: 24rpx;
						}
					}
					.num-stock {
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666666;
						font-size: 24rpx;
					}
					.price-account {
						box-sizing: border-box;
						padding-top: 10rpx;
						font-size: 32rpx;
						display: flex;
						justify-content: space-between;
						align-items: center;
						.price {
							color: #e23a3a;
							font-weight: 500;
						}
						.prices {
							color: #2d8cf0;
							font-weight: 500;
						}
						.carnum {
							font-size: 24rpx;
							color: #999999;
						}
						.accout {
							// background: #007AFF;
							width: 40%;
							display: flex;
							justify-content: space-between;
							align-items: center;
						}
					}
				}
			}
		}
	}

	.tobtn {
		width: 100%;
		display: flex;
		justify-content: flex-end;
		align-items: center;
		background: #ffffff;
		box-sizing: border-box;
		padding: 30rpx 30rpx;
		// margin-top: 50rpx;
		position: fixed;
		bottom: 0rpx;
		left: 0;
		.price {
			font-size: 32rpx;
			color: #282828;
			width: 30%;
		}
		.btnitem {
			margin-left: 30rpx;
			width: 30%;
			height: 60rpx;
			background: #e23a3a;
			text-align: center;
			line-height: 60rpx;
			font-size: 24rpx;
			color: #ffffff;
		}
	}
}

.iptcolor {
	color: #09bb07;
}
</style>
