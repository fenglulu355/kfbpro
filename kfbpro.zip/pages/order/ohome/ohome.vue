<template>
	<view class="addgoods">
		<view class="headertop">
			<view class="bg isbgs" v-show="isShow"></view>
			<topback :topback="'工单'" :iscenter="false" :iswhite="true" :isbg="true"></topback>
			<view class="iconfont srcicon">&#xe620;</view>
			<input type="text" value="" placeholder="搜索客户名称,联系人,手机号" />
			<view class="iconfont adds" @click="ispop = !ispop">&#xe628;</view>

			<view class="selectbox">
				<view class="pop" v-if="ispop">
					<view class="addnew" :class="issel == 0 ? 'sel' : ''" @click="ptcg">发起平台采购</view>
					<view class="fzgl" :class="issel == 1 ? 'sel' : ''" @click="xxcg">发起线下采购</view>
					<view class="addnew" :class="issel == 2 ? 'sel' : ''" @click="addressgl">收获地址管理</view>
				</view>
				<view class="tabs"><tabbar :tabbarlist="mtabbarlist" :type="1" @change="tonav"></tabbar></view>
			</view>
		</view>
		<!-- 		<view class="tabs"><tabbar :tabbarlist="mtabbarlist" :type="1" @change="tonav"></tabbar></view>
 -->
		<view class="content">
			<!-- tabbar -->
			<view class="goodsinfo">
				<view class="orderlist">
					<view class="orderli" v-for="(item, index) in orderli" :key="index" @click="tomain(item, index)">
						<view class="o-top">
							<text class="time">{{ item.time }}</text>
							<text class="type">{{ item.type }}</text>
						</view>
						<view class="o-center">
							<view class="pic"><image src="../../../static/logo.png" mode=""></image></view>
							<view class="oc-center">
								<view class="name">
									<text class="names">{{ item.name }}</text>
									<image src="../../../static/images/otel.png" mode=""></image>
								</view>
								<view class="carnum">{{ item.carnum }}</view>
								<view class="incomes">
									<view class="income">
										预计收入
										<text class="text">￥{{ item.income }}</text>
									</view>
									<view class="toopen" @click="showpel(index)">
										<text v-html="pselidx == index ? '收起' : '展开'"></text>
										<text>></text>
									</view>
								</view>

								<view class="pricemain" :class="index == pselidx ? 'psle' : ''">
									<view class="priceli">
										<text>配件金额</text>
										<text>¥456456.00</text>
									</view>
									<view class="priceli">
										<text>服务金额</text>
										<text>¥456456.00</text>
									</view>
									<view class="priceli">
										<text>优惠金额</text>
										<text>¥456456.00</text>
									</view>
									<view class="priceli">
										<text>待收金额</text>
										<text>¥456456.00</text>
									</view>
								</view>
							</view>
						</view>
						<view class="o-bot">
							<view class="cancle">取消订单</view>
							<view class="accounts" @click="tocollection">结算</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
import tabbar from '../../../components/tabbar/tabbar.vue';
import goodsitem from '../../../components/goodsitem/goodsitem';
import Select from '../../../components/Select/Select.vue';
export default {
	data() {
		return {
			pselidx: null,
			ispop: false,
			issel: 0,
			showindex: 0,
			tabbarlist: ['平台采购', '线下采购'],
			mtabbarlist: ['全部', '待确认', '待发货', '已发货', '已完成', '已取消'],
			isShow: false,
			goodsinfo: [],
			orderli: [
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' },
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' },
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' },
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' },
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' },
				{ time: '2+54684', type: '进行中', name: '政府', carnum: 'sdasda', income: '5465' }
			]
		};
	},

	methods: {
		tocollection() {
			uni.navigateTo({
				url: '../collection/collection'
			});
		},
		showpel(index) {
			if (this.pselidx != index) {
				this.pselidx = index;
			} else {
				this.pselidx = null;
			}
		},
		ptcg() {
			console.log(1);
			this.issel = 0;
			uni.navigateTo({
				url: '../../stores/addgoods/addgoods?from=' + 'purchase'
			});
		},
		xxcg() {
			this.issel = 1;
			// uni.navigateTo({
			// 	url: '../goodsgroup/goodsgroup'
			// });
		},
		addressgl() {
			this.issel = 2;
			uni.navigateTo({
				url: '../ordermain/ordermain'
			});
		},
		toinventory() {
			uni.navigateTo({
				url: '../inventory/inventory'
			});
		},

		tomain(item, index) {
			uni.navigateTo({
				url: '../goodsmain/goodsmain'
			});
		}
	},

	components: { topback, tabbar, goodsitem, Select }
};
</script>

<style lang="less" scoped>
.addgoods {
	width: 100%;
	background: #fafafa;
	position: relative;
	.add {
		position: fixed;
		right: 20rpx;
		bottom: 20%;
		image {
			width: 138rpx;
			height: 138rpx;
		}
	}
	.headertop {
		width: 100%;
		height: 100rpx;
		background: #ffffff;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 11111;
		display: flex;
		justify-content: space-between;
		align-items: center;
		.bg {
			position: absolute;
			top: 0;
			z-index: 111;
			width: 100%;
			height: 200rpx;
		}
		.srcicon {
			position: absolute;
			left: 32%;
			z-index: 1;
			color: #b7b7b7;
		}

		input {
			box-sizing: border-box;
			position: absolute;
			// top: 50%;
			// transform: translateY(-50%);
			left: 30%;
			background: #f7f7f7;
			width: 50%;
			height: 55rpx;
			border-radius: 25rpx;
			padding: 0 15rpx 0 55rpx;
			font-size: 24rpx;
		}
		.adds {
			position: absolute;
			right: 10rpx;
			font-size: 82rpx;
			color: #2d8cf0;
		}
		.selectbox {
			background: #ffffff;
			position: fixed;
			z-index: 11111111111111111;
			top: 100rpx;
			left: 0;
			width: 100%;
			height: 100rpx;
			.pop {
				width: 30%;
				background: #ffffff;
				position: absolute;
				top: 20rpx;
				right: 40rpx;
				z-index: 11111111111111111;
				font-size: 28rpx;
				
				view{
					text-align: center;
					line-height: 60rpx;
				}
				.sel {
					color: #2d8cf0;
				}
			}
		}
		.tabs {
			width: 100%;
			height: 100rpx;
			box-sizing: border-box;
			padding-top: 20rpx;
			background: #ffffff;
			// position: fixed;
			// top: 200rpx;
			// left: 0;
			// z-index: 11111;
		}
	}
}

.content {
	box-sizing: border-box;
	padding: 180rpx 30rpx 30rpx 30rpx;

	.salelist {
		width: 100%;
	}
}
.btns {
	width: 100%;
	display: flex;
	justify-content: flex-end;
	box-sizing: border-box;
	padding: 40rpx 0;
	.item {
		width: 200rpx;
		height: 60rpx;
		background: #2d8cf0;
		border-radius: 5rpx;
		color: #ffffff;
		font-size: 32rpx;
		text-align: center;
		line-height: 60rpx;
	}
	.cancle {
		background: #e23a3a;
	}
}
.isbgs {
	background: rgba(0, 0, 0, 0.5);
}

.goodsinfo {
	box-sizing: border-box;
	padding: 30rpx 0;
	.orderlist {
		width: 100%;
		box-sizing: border-box;
		padding-top: 15rpx;
		.orderli {
			background: #ffffff;
			box-sizing: border-box;
			margin: 15rpx 0;
			padding: 30rpx 10rpx;
			color: #666666;
			.o-top {
				width: 100%;
				font-size: 24rpx;
				display: flex;
				justify-content: space-between;
				box-sizing: border-box;
				padding-bottom: 20rpx;
				border-bottom: 1rpx solid #e5e5e5;
			}
			.o-center {
				box-sizing: border-box;
				padding: 30rpx 0;
				display: flex;
				justify-content: space-between;
				.pic {
					width: 150rpx;
					height: 150rpx;
					image {
						width: 150rpx;
						height: 150rpx;
					}
				}
				.oc-center {
					width: 100%;
					box-sizing: border-box;
					padding-left: 30rpx;
					image {
						width: 50rpx;
						height: 50rpx;
					}
					.name,
					.incomes {
						display: flex;
						justify-content: space-between;
					}
					.name {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
					}
					.carnum {
						color: #666666;
						font-size: 26rpx;
						line-height: 60rpx;
					}
					.incomes {
						font-size: 28rpx;
						font-weight: 500;
						.text {
							color: #e23a3a;
							box-sizing: border-box;
							padding-left: 20rpx;
						}
					}
					.toopen {
						color: #b7b7b7;
						font-size: 24rpx;
					}
				}
			}
			.o-bot {
				width: 100%;
				display: flex;
				justify-content: flex-end;
				view {
					width: 30%;
					height: 60rpx;
					line-height: 60rpx;
					background: #cccccc;
					font-size: 32rpx;
					text-align: center;
					margin-left: 20rpx;
					color: #ffffff;
					border-radius: 5rpx;
				}
				.accounts {
					background: #2d8cf0;
				}
			}
		}
	}
}
.pricemain {
	display: none;
	width: 100%;
	.priceli {
		display: flex;
		justify-content: space-between;
		color: #b7b7b7;
		font-size: 26rpx;
		box-sizing: border-box;
		margin-top: 20rpx;
	}
}
.psle {
	display: block;
}
</style>
