<template>
	<view class="cusmain">
		<view class="top"><topback :topback="'确认账单'" :iscenter="true"></topback></view>
		<view class="content">
			<view class="p-top">
				<image src="../../../static/images/icon_daishou.png" mode=""></image>
				<view class="price">+500.00</view>
				<view class="text">待收金额</view>
			</view>
		</view>
		<view class="list">
			<view class="li">
				<text class="name">配件费</text>
				<text class="prc">￥5489</text>
			</view>
			<view class="li">
				<text class="name">配件费</text>
				<text class="prc">￥5489</text>
			</view>
			<view class="li">
				<text class="name">配件费</text>
				<text class="prc">￥5489</text>
			</view>
		</view>
		<view class="btn">
			<view class="item addprc">添加优惠金额</view>
			<view class="item red" @click="toclc">收款</view>
		</view>
	</view>
</template>

<script>
import topback from '../../../components/topback/topback.vue';
export default {
	data() {
		return {};
	},
	components: { topback },
	methods: {
		tozdmain(item, index) {},
		toclc(){
			uni.navigateTo({
				url:'../curmoney/curmoney'
			})
		}
	}
};
</script>

<style lang="less" scoped>
.cusmain {
	width: 100%;
	height: 100%;

	position: relative;
	box-sizing: border-box;
	padding: 120rpx 0rpx;
	.top {
		background: #2d8cf0;
		width: 100%;
		position: absolute;
		top: 0;
	}
}
.content,
.list {
	background: #ffffff;
	box-sizing: border-box;
	padding: 30rpx 30rpx;
}
.content {
	text-align: center;
	image {
		width: 100rpx;
		height: 100rpx;
	}
	.price {
		font-size: 60rpx;
		color: #282828;
	}
	.text {
		font-size: 24rpx;
		color: #999999;
	}
}
.list {
	margin-top: 30rpx;
	.li {
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 28rpx;
		color: #666666;
		box-sizing: border-box;
		padding: 10rpx 0;
		.prc {
			font-size: 26rpx;
			color: #333333;
		}
	}
}
.btn {
	background: #ffffff;
	box-sizing: border-box;
	padding: 0 30rpx;
	position: fixed;
	bottom: 0;
	left: 0;
	width: 100%;
	height: 100rpx;
	display: flex;
	justify-content: flex-end;
	align-items: center;
	.item {
		background: #2d8cf0;
		color: #ffffff;
		font-size: 32rpx;
		min-width: 200rpx;
		box-sizing: border-box;
		padding: 10rpx 20rpx;
		text-align: center;
		border-radius: 5rpx;
		margin-left: 30rpx;
	}
	.red{
		background: #E23A3A;
	}
}
</style>
