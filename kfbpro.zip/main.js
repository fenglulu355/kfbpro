import Vue from 'vue'
import App from './App'

//引入vuex
import store from './store'
//把vuex定义成全局组件
Vue.prototype.$store = store


import XRequest  from './libs/netRequest.js';
Vue.prototype.$request  = XRequest 
Vue.prototype.$baseUrl = 'https://testmd.carszone.cn';
Vue.prototype.$picUrl = 'https://kfbnet2019.obs.cn-north-1.myhuaweicloud.com';
Vue.config.productionTip = false

App.mpType = 'app'









//获取不同机型的头部高度
Vue.prototype.isBarHeight999 = function() {
	return new Promise((resolve, reject) => {
		var that = this
		var isTemp = {}
		uni.getSystemInfo({
			success(res) {
				let totalTopHeight = 80
				if (res.model.indexOf('iPhone X') !== -1) {
					totalTopHeight = 88
				} else if (res.model.indexOf('iphone') !== -1) {
					totalTopHeight = 80
				}
				isTemp['statusBarHeight'] = res.statusBarHeight
				isTemp['titleBarHeight'] = totalTopHeight - res.statusBarHeight
				isTemp['allHeight'] = totalTopHeight
				resolve(isTemp)
			},
			fail(e) {
				reject(e)
			}
		})
	})
}




import "./static/icofont/iconfont.css";
const app = new Vue({
	...App,
	//挂载
	store
})
app.$mount()
