<template>
	<view class="headers">
		<view class="noceniswhite" v-if="iswhite == true && iscenter == false">
			<text class="span" @click="toback"><</text>
			<text class="text">{{ topback }}</text>
		</view>
		<view
			v-if="nums"
			class="bgpic"
			style="background: url(../../static/images/bg_1.png);
				background-position: center;
				background-size: cover;
				background-repeat: no-repeat;"
		>
			<view class="texts">{{ nums.text }}</view>
			<view class="num">{{ nums.num }}</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	props: ['topback', 'iscenter', 'isbg', 'nums', 'iswhite'],
	created() {
		console.log(this.topback, this.nums);
	},
	methods: {
		toback() {
			uni.navigateBack({});
		}
	}
};
</script>

<style lang="less" scoped>
.noceniswhite {
	background: #FFFFFF;
	width: 100%;
	color: #282828;
	height: 100rpx;
	font-size: 40rpx;
	line-height: 100rpx;
	box-sizing: border-box;
	padding-left: 60rpx;
	font-weight: 600;
	.span {
		box-sizing: border-box;
		position: absolute;
		left: 20rpx;
	}
	.text {
		position: absolute;
		left: 70rpx;
	}
}
.bluebg {
	background: #2d8cf0;
}
.topbacks {
	width: 100%;
	color: #ffffff;
	height: 100rpx;
	font-size: 40rpx;
	line-height: 100rpx;
	box-sizing: border-box;
	padding-left: 60rpx;
	font-weight: 600;
	.span {
		box-sizing: border-box;
		position: absolute;
		left: 20rpx;
	}
	.text {
		position: absolute;
		left: 70rpx;
	}
}
.topback {
	// position: fixed;
	// top: 0;
	// left: 0;
	// z-index: 11;
	top: 15rpx;
	width: 100%;
	color: #ffffff;
	height: 100rpx;
	font-size: 40rpx;
	line-height: 100rpx;
	box-sizing: border-box;
	padding-left: 60rpx;
	font-weight: 600;

	.span {
		box-sizing: border-box;
		position: absolute;
		left: 20rpx;
	}
	.text {
		position: absolute;
		left: 50%;
		transform: translateX(-50%);
	}
}
.incenter {
	// background: #2d8cf0;
	.text {
		position: absolute;
		left: 50%;
		transform: translateX(-50%);
	}
}
.bgpic {
	width: 100%;
	height: 325rpx;
	text-align: center;
	color: #ffffff;
	box-sizing: border-box;
	padding-top: 120rpx;
	font-size: 28rpx;
	.texts {
		box-sizing: border-box;
		padding-bottom: 30rpx;
		font-size: 40rpx;
		font-weight: 500;
	}
}
</style>
