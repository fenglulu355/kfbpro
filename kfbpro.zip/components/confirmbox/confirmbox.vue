<template>
	<view class="confirm-inpt" v-if="isshow == true">
		<view class="ci-box">
			<view class="title">{{ title }}</view>
			<view class="ipt">
				<text>￥</text>
				<input type="number" value="" v-model="confirminput" />
			</view>
			<view class="btn">
				<view class="cancle" @click="cancle">取消</view>
				<view class="cur" @click="confirm">确定</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			confirminput: null,
			before: null
		};
	},
	props: ['title', 'isshow'],
	methods: {
		confirm() {
			if (this.confirminput == null) {
				this.$emit('change', 0);
			} else {
				this.$emit('change', this.confirminput);
			}
			this.before = this.confirminput;
			this.confirminput = null;
		},
		cancle() {
			this.$emit('change', this.before);
		}
	}
};
</script>

<style lang="less" scoped>
.confirm-inpt {
	background: rgba(0, 0, 0, 0.5);
	width: 100%;
	height: 2000rpx;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 11111111;
	.ci-box {
		background: #ffffff;
		width: 80%;
		margin: 500rpx auto;
		border-radius: 60rpx;
		box-sizing: border-box;
		padding: 10rpx 15rpx;
		.title {
			text-align: center;
			font-size: 36rpx;
			line-height: 80rpx;
			color: #333333;
		}
		.ipt {
			width: 100%;
			height: 100rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 32rpx;
			color: #333333;
			text {
			}
			input {
				width: 30%;
				border-bottom: 1rpx solid #eaeaea;
			}
		}
		.btn {
			width: 100%;
			height: 100rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			view {
				width: 40%;
				height: 80rpx;
				font-size: 30rpx;
				text-align: center;
				line-height: 80rpx;
				color: #4d9df2;
			}
			.cancle {
				color: #999999;
			}
		}
	}
}
</style>
