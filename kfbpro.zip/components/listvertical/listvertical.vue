<template>
	<view class="cusinfo seritem" v-if="type == 'service'">
		<view class="i-left">
			<view class="il-top item">
				<text class="name">{{ curinfo.name }}</text>
				<text class="type">{{ curinfo.type }}</text>
			</view>
			<view class="il-bot item">
				<text class="price">￥{{ curinfo.price }}</text>
				<text class="unit">{{ curinfo.unit }}</text>
			</view>
		</view>
		<view class="i-right">
			<image @click="todel" src="../../static/images/icon_delete@2x.png" mode=""></image>
			<image @click="toedit" src="../../static/images/icon_bianji@2x.png" mode=""></image>
		</view>
	</view>

	<view class="cusinfo" v-else>
		<image :src="curinfo.icon" mode=""></image>
		<view class="infos">
			<view class="title">{{ curinfo.title }}</view>
			<view class="name-tel">
				<text class="name">{{ curinfo.name }}</text>
				<text class="tel">{{ curinfo.tel }}</text>
			</view>
			<view class="address" v-if="curinfo.address">地址：{{ curinfo.address }}</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	props: ['curinfo', 'type'],
	methods: {
		todel() {
			this.$emit('del', this.curinfo);
		},
		toedit() {
			this.$emit('edit', this.curinfo);
		}
	},
	created() {
		console.log(this.curinfo, this.type);
	}
};
</script>

<style lang="less" scoped>
.seritem {
	// background: #4CD964;
	width: 100%;
	display: flex;
	justify-content: space-between;
	.i-left {
		width: 80%;
		box-sizing: border-box;
		padding-right: 5%;

		.item {
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			box-sizing: border-box;
			padding: 10rpx 0;
		}
		.name,
		.price {
			font-size: 32rpx;
			color: #333333;
		}
		.type {
			font-size: 26rpx;
			color: #666666;
		}
		.unit {
			font-size: 24rpx;
			color: #666666;
		}
	}
	.i-right {
		// background: #007AFF;
		width: 20%;
		display: flex;
		justify-content: space-around;
		align-items: center;
		image {
			width: 38rpx;
			height: 38rpx;
		}
	}
}
.cusinfo {
	width: 100%;
	display: flex;
	justify-content: flex-start;
	box-sizing: border-box;
	padding: 10rpx 10rpx;
	image {
		width: 100rpx;
		height: 100rpx;
		border-radius: 50%;
	}

	.infos {
		box-sizing: border-box;
		padding-left: 20rpx;
		align-self: center;
		.title {
			font-size: 32rpx;
			box-sizing: border-box;
			// padding-top: 20rpx;
			color: #333333;
		}
		.name-tel {
			box-sizing: border-box;
			padding-top: 10rpx;
			font-size: 28rpx;
			color: #666666;
		}
		.tel {
			box-sizing: border-box;
			padding-left: 20rpx;
		}
		.address {
			box-sizing: border-box;
			padding-top: 20rpx;
			font-size: 24rpx;
			color: #999999;
		}
	}
}
</style>
