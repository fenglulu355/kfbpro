<template>
	<view class="select selection">
		<view class="inner" v-clickOut="test">
			<view class="inputWrapper" @click="showOptions = !showOptions">
				<input type="text" readonly :placeholder="options[0].name" :value="selected" />
				<!-- 此处可以自定义图片 -->
				<text class="iconfont icon-zhankaishangxia">↓</text>
			</view>
			<view class="options" v-show="showOptions">
				<view class="li" v-for="(item, index) in options" :key="index" @click="choose(item.name)">{{ item.name }}</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			selected: '',
			showOptions: false
		};
	},
	props: {
		options: {
			type: Array
		}
	},
	methods: {
		choose(name) {
			this.showOptions = false;
			if (name !== this.selected) {
				this.selected = name;
				this.$emit('selected', name);
			}
		},
		outsideDirec() {
			this.showOptions = false;
		},
		test() {
			this.showOptions = false;
		}
		// example2() {
		//   return "xxx";
		// }
	},
	directives: {
		clickOut: {
			bind: function(el, binding) {
				function handler(e) {
					if (el.contains(e.target)) return false;
					if (binding.expression) {
						binding.value();
					}
				}
				el.handler = handler;
				document.addEventListener('click', el.handler);
			},
			unbind: function(el) {
				document.removeEventListener('click', el.handler);
			}
		}
	}
};
</script>

<style scoped>
.inner {
	/* background: firebrick; */
	position: relative;
	/* margin: 0 auto */
	width: 80%;
	height: 60rpx;
	font-size: 32rpx;
	color: #666666;
}
.inner > .options {
	position: absolute;
	left: 0;
	right: 0;
	top: 65rpx;
	z-index: 1;
	box-sizing: border-box;
	padding: 0rpx 15rpx;
	background-color: #fff;

	box-shadow: 0 0 4rpx #ddd;
	border-radius: 3px;
	width: 90%;
	/* background: orangered; */
	overflow-y: scroll;
}
/* 隐藏滚动条 */
.options::-webkit-scrollbar {
	display: none;
}
.inner > .options > .li {
	border-bottom: 1rpx solid #ddd;
	height: 70rpx;
	line-height: 70rpx;
	font-size: 24rpx;
	text-align: left;
	/* background: brown; */
	cursor: pointer;
}
.inner > .options :last-child {
	border: none;
}

.inner .inputWrapper {
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: flex-start;
	align-items: center;
}
.inner .inputWrapper > input {
	/* background: #007aff; */
	width: 80%;
	height: 100%;
	font-size: 32rpx;
	padding: 0 10rpx;
	outline: none;
}
</style>
