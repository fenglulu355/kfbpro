import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)


const files = require.context('./modules', false, /\.js$/);
const modules = {};


files.keys().forEach(key => {
  modules[key.replace(/(\.\/|\.js)/g, '')] = files(key).default
});

const store = new Vuex.Store({
	
	
	state: {
		barheight: '',
		authorization: '',
		shopid: '',
		orderinfo:'',
		serverlist:[]
	},
	mutations: {
		// 设置authorization
		SET_AUTHORIZATION: function(state, e) {
			state.authorization = e
		},
		// 设置shopid
		SET_SHOPID: function(state, e) {
			state.shopid = e
		},
		// 设置服务列表
		SET_SERVERLIST:function(state,e){
			state.serverlist=e
		},
		
		
		// 设置根据id请求的工单详情
		SET_ORDERINFO:function(state,e){
			state.orderinfo=e
		},
		
		
		
		setbarheight: function(state, e) {
			uni.getSystemInfo({
				success: (res) => {
					console.log(res, 'res');
					state.barheight = res.statusBarHeight
					alert(res.statusBarHeight)
				}
			})
		}

	},
	actions: {},
	  modules,
	  // getters
})
export default store
